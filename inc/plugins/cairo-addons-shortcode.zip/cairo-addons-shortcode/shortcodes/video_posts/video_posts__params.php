<?php

$post_categories = get_terms("category");
$post_categories_array = array();
$post_categories_array[__("All Categories", 'cairo')] = "-";
foreach($post_categories as $post_category) {
  $post_categories_array[$post_category->name] =  $post_category->term_id;
}

// ==========================================================================================
// Video Format Posts Style
// ==========================================================================================

vc_map( array(
  "name" 					=> esc_html__("Video Playlist", 'cairo'),
  "base" 					=> "codepages_video_module",
  "class" 				=> "",
  "category" 			=> esc_html__("Cairo Theme", 'cairo'),
  "icon"      		=> "ti ti-control-forward",
  "description" 	=>esc_html__( 'Bulid Your Layout Posts Blog.','cairo'),
  "params"				=> array(
    array(
      "type" => "dropdown",
      "heading" => "Style",
      "param_name" => "style",
      "admin_label" => true,
      "value" => array(
        esc_html__("None Select", 'cairo') => "none",
        esc_html__("style 1", 'cairo') => "style1",
        esc_html__("style 2", 'cairo') => "style2",
      ),
      "description" => "This changes the layouts of the grids"
    ),
    //Style 1
    array(
      'type'	=> 'imagethup',
      'heading'	=> '',
      'param_name'	=> 'styleoneimage',
      'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_video_playlist_1.png',
      'dependency' => Array('element' => "style", 'value' => array('style1'))
    ),
    //Style 2
    array(
      'type'	=> 'imagethup',
      'heading'	=> '',
      'param_name'	=> 'styletwoimage',
      'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_video_playlist_2.png',
      'dependency' => Array('element' => "style", 'value' => array('style2'))
    ),

    array(
      "type" => "dropdown",
      "heading" => "Dark Or Light",
      "param_name" => "darkorlight",
      "admin_label" => true,
      "value" => array(
        esc_html__("None Select", 'cairo') => "none",
        esc_html__("Dark Style", 'cairo') => "dark",
        esc_html__("Light Style", 'cairo') => "light",
      ),
      "description" => "This changes the layouts of the grids"
    ),

    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Title Text",'cairo'),
      "description" => esc_html__("Title Block Text",'cairo'),
      "param_name" => "playlisttitle",
      "value" => "",
    ),

    array(
      "type" => "textfield",
      "class" => "",
      "heading" => "Number of posts",
      "param_name" => "postcount",
      "value" => "",
      "description" => "The number of posts to show."
    ),

    //Exclude Post
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Exclude Posts",'cairo'),
      "description" => esc_html__("Enter exclude posts(s) id. Separate with commas 1,2,3 etc.",'cairo'),
      'group' => esc_html__("Exclude Settings", 'cairo'),
      "param_name" => "excludeposts",
      "value" => "",
    ),
    //Exclude Category
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Exclude Category",'cairo'),
      "description" => esc_html__("Enter exclude category id. Separate with commas 1,2,3 etc.",'cairo'),
      'group' => esc_html__("Exclude Settings", 'cairo'),
      "param_name" => "excludecategory",
      "value" => "",
    ),
    //Exclude Tag
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Exclude Tags",'cairo'),
      "description" => esc_html__("Enter the tag ID you would like to display seperated by comma",'cairo'),
      'group' => esc_html__("Exclude Settings", 'cairo'),
      "param_name" => "excludetag",
      "value" => "",
    ),

    array(
      "type" => "dropdown",
      "heading" => esc_html__("Post Source", 'cairo'),
      "description" => esc_html__("Select the source of the posts you'd like to show.", 'cairo'),
      "group" => esc_html__("Post Source", 'cairo'),
      "param_name" => "source",
      "value" => array(
        'None Select' => 'none',
        'By Category' => 'by-category',
        'By Post ID' => 'by-id',
        'By Tag' => 'by-tag',
        'By Author' => 'by-author',
      ),
      "admin_label" => true,
    ),
    array(
      "type" => "dropdown",
      "heading" => esc_html__("Post Categories", 'cairo'),
      "description" => esc_html__("Which categories would you like to show?", 'cairo'),
      'group' => esc_html__("Post Source", 'cairo'),
      "param_name" => "cat",
      "value" => $post_categories_array,
      "dependency" => Array('element' => "source", 'value' => array('by-category'))
    ),
    array(
      "type" => "textfield",
      "heading" => esc_html__("Post IDs", 'cairo'),
      "description" => esc_html__("Enter the post IDs you would like to display seperated by comma", 'cairo'),
      'group' => esc_html__("Post Source", 'cairo'),
      "param_name" => "postid",
      "dependency" => Array('element' => "source", 'value' => array('by-id'))
    ),
    array(
      "type" => "textfield",
      "heading" => esc_html__("Tag slugs", 'cairo'),
      "description" => esc_html__("Enter the tag ID you would like to display seperated by comma", 'cairo'),
      'group' => esc_html__("Post Source", 'cairo'),
      "param_name" => "tagslugs",
      "dependency" => Array('element' => "source", 'value' => array('by-tag'))
    ),
    array(
      "type" => "textfield",
      "heading" => esc_html__("Author IDs", 'cairo'),
      "description" => esc_html__("Enter the Author IDs you would like to display seperated by comma", 'cairo'),
      'group' => esc_html__("Post Source", 'cairo'),
      "param_name" => "authorids",
      "dependency" => Array('element' => "source", 'value' => array('by-author'))
    ),

    //Pos Order By
    array(
    "type" => "dropdown",
    "class" => "",
    "heading" => esc_html__("Post Order By",'cairo'),
    "description" => esc_html__("Post Order By",'cairo'),
    "group" => esc_html__("Post Source", 'cairo'),
    "param_name" => "videoorderby",
      "value" => array(
        esc_html__("None Select", 'cairo') => "none",
        esc_html__("Date", 'cairo') => 'date',
        esc_html__("Random", 'cairo') => 'rand',
        esc_html__("Comment Count", 'cairo') => 'comment_count',
      )
    ),
  ),
));
