<?php
/**
 *
 * Heading Box
 * @since 1.0.0
 * @version 1.0.0
 *
 */

function codepages_heading( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'style'							=>	'',
			'sub_title_text'		=>  '',
			'title_text'				=>  '',
			'content'						=>  '',
			'extra_class'				=>  '',
			'extra_id'					=>  '',
		), $atts
	);

	$output = '';

	$modulestyle 				= $atts['style'];
	$blocktitle 				= $atts['title_text'];
	$blockclass 				= $atts['extra_class'];
	$blockid    				= $atts['extra_id'];
	$content 						= wpb_js_remove_wpautop($content, true);

  // ==========================================================================================
  // Module Icon Bos Style
  // ==========================================================================================

	$output .= '<div class="codepages-heading codepages-heading-'.$modulestyle.' '.$blockclass.'">';
	$output .= '<div class="codepages-heading-wrapper">';
		$output .= '<h2 class="title-heading">'.$blocktitle.'</h2>';
	$output .= '</div>';

	$output .= '</div>';
	return $output;

}
add_shortcode("codepages_heading_module", "codepages_heading");
