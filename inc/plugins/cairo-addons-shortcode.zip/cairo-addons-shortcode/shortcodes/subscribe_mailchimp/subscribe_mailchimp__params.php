<?php
// ==========================================================================================
// MailChimp Moduel Element
// ==========================================================================================

vc_map( array(
  "name" 					=> esc_html__("MailChimp", 'cairo'),
  "base" 					=> "codepages_subscribe_mailchimp_module",
  "class" 				=> "",
  "category" 			=> esc_html__("Cairo Theme", 'cairo'),
  "icon"      		=> "ti ti-email",
  "description" 	=>esc_html__( 'Bulid Your Layout Posts Blog.','cairo'),
  "params"				=> array(
    array(
      "type" => "dropdown",
      "heading" =>  esc_html__("Subscribe Style",'cairo'),
      "param_name" => "style",
      "admin_label" => true,
      "value" => array(
        esc_html__("None Select", 'cairo') => "none",
        esc_html__("Style 1", 'cairo') => "style1",
        esc_html__("Style 2", 'cairo') => "style2",
      ),
      "description" => "This changes the style of Subscribe",
    ),
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Title Subscribe", 'cairo'),
      "param_name" => "title_text",
      "value" => "",
      "description" => esc_html__( "add your title of subscribe.", 'cairo' ),
    ),
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Description Subscribe", 'cairo'),
      "param_name" => "description_text",
      "value" => "",
      "description" => esc_html__( "add your description of subscribe.", 'cairo' ),
    ),
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Form ID Subscribe", 'cairo'),
      "param_name" => "formid",
      "value" => "",
      "description" => esc_html__( "add the form id of subscribe.", 'cairo' ),
    ),
    array(
      "type" => "dropdown",
      "heading" =>  esc_html__("Subscribe Style",'cairo'),
      "param_name" => "lightordark",
      "admin_label" => true,
      "value" => array(
        esc_html__("None Select", 'cairo') => "none",
        esc_html__("Light", 'cairo') => "light",
        esc_html__("Dark", 'cairo') => "dark",
      ),
      "description" => "Select design element light or dark Subscribe",
    ),
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Extra Class", 'cairo'),
      "param_name" => "extra_class",
      "value" => "",
      "description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'cairo' ),
      'group' => esc_html__("Extra Settings", 'cairo'),
    ),
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Extra ID", 'cairo'),
      "param_name" => "extra_id",
      "value" => "",
      "description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a id name and then refer to it in your css file.", 'cairo' ),
      'group' => esc_html__("Extra Settings", 'cairo'),
    ),
  ),
));
