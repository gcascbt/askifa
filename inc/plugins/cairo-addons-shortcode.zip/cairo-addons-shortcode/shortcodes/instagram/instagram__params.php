<?php
// ==========================================================================================
// Instagram Element
// ==========================================================================================

vc_map( array(
  "name" 					=> esc_html__("Instagram", 'cairo'),
  "base" 					=> "codepages_instagram_module",
  "class" 				=> "",
  "category" 			=> esc_html__("Cairo Theme", 'cairo'),
  "icon"      		=> "fa fa-instagram",
  "description" 	=>esc_html__( 'Bulid Your Layout Posts Blog.','cairo'),
  "params"				=> array(
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Title", 'cairo'),
      "param_name" => "title_insta",
      "value" => "",
      "description" => esc_html__( "add your block title.", 'cairo' ),
    ),
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Username", 'cairo'),
      "param_name" => "username_insta",
      "value" => "",
      "description" => esc_html__( "add your instagram username.", 'cairo' ),
    ),
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Number of Photos", 'cairo'),
      "param_name" => "count_img",
      "value" => "",
      "description" => esc_html__( "add namber images show.", 'cairo' ),
    ),
    array(
      "type" => "dropdown",
      "heading" =>  esc_html__("Instagram Column",'cairo'),
      "param_name" => "style",
      "admin_label" => true,
      "value" => array(
        esc_html__("Six Columns", 'cairo') => "col-md-2",
        esc_html__("Four Columns", 'cairo') => "col-md-3",
        esc_html__("Three Columns", 'cairo') => "col-md-4",
      ),
      "description" => "This changes the layouts of the Instagram",
    ),
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Extra Class", 'cairo'),
      "param_name" => "extra_class",
      "value" => "",
      "description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'cairo' ),
      'group' => esc_html__("Extra Settings", 'cairo'),
    ),
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Extra ID", 'cairo'),
      "param_name" => "extra_id",
      "value" => "",
      "description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a id name and then refer to it in your css file.", 'cairo' ),
      'group' => esc_html__("Extra Settings", 'cairo'),
    ),
  ),
));
