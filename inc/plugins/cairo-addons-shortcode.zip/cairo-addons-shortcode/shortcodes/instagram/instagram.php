<?php
/**
 *
 * Instagram Module
 * @since 1.0.0
 * @version 1.0.0
 *
 */

function codepages_instagram( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'style'		          =>	'col-md-2',
			'title_insta'				=>	'',
			'username_insta'		=>	'',
			'count_img'		      =>  '',
			'extra_class'				=>  '',
			'extra_id'					=>  '',
		), $atts
	);


	$output = '';

	$style 							= $atts['style'];
	$title_insta 				= $atts['title_insta'];
	$username 				  = $atts['username_insta'];
	$number         		= $atts['count_img'];
	$blockclass 				= $atts['extra_class'];
	$blockid    				= $atts['extra_id'];
	$media_array 				= scrape_instagram( $atts['username_insta'], $atts['count_img'] );

  // ==========================================================================================
  // Module Icon Bos Style
  // ==========================================================================================

	$output .= '<div class="codepages-instagram">';
	$output .= '<div class="codepages-instagram-wrapper">';
	$output .= '<h2 class="title-insta-block"><i class="fa fa-instagram"></i> '.$title_insta.' </h2>';

	$media_array = array_filter( $media_array );
	foreach ( $media_array as $d ) {
		$output .= '<div class="'.$style.' col-sm-12 col-xs-12 none-padding">';
		$output .='
			<a href="'. esc_url( $d['link'] ) .'" target="_blank" rel="nofollow">
				<img src="'. esc_url( $d['images']['thumbnail'] ) .'"  class="trs" alt="'. esc_attr( $d['caption'] ) .'" title="'. esc_attr( $d['caption'] ).'">
			</a>
		';
		$output .= '</div>';
	}
	$output .= '</div>';
	$output .= '</div>';
	return $output;

}
add_shortcode("codepages_instagram_module", "codepages_instagram");

function scrape_instagram( $username, $token, $method = 'username', $count = 12, $max_id = '' ) {
	$codepages_response = wp_remote_get( get_url( $username, $token, $method, $max_id ) , array(
		'timeout' => 10,
	));

	if ( !is_wp_error( $codepages_response ) && $codepages_response['response']['code'] == '200' )
	{
		$data_images = array();

		if ( $method === 'username')
		{
			$data      = explode( 'window._sharedData = ', $codepages_response['body'] );
			$data_json = explode( ';</script>', $data[1] );
			$data_json = json_decode( $data_json[0], TRUE );

			foreach ( $data_json['entry_data']['ProfilePage'][0]['graphql']['user']['edge_owner_to_timeline_media']['edges'] as $image )
			{
				$data_images[] = array(
					'id'          => $image['node']['id'],
					'time'        => $image['node']['taken_at_timestamp'],
					'like'        => $image['node']['edge_liked_by']['count'],
					'comment'     => $image['node']['edge_media_to_comment']['count'],
					'caption'     => !empty( $image['node']['edge_media_to_caption']['edges'][0]['node']['text'] ) ? preg_replace('/[^a-zA-Z0-9\-]/', ' ', $image['node']['edge_media_to_caption']['edges'][0]['node']['text']) : '',
					'link'        => trailingslashit( '//instagram.com/p/' . $image['node']['shortcode'] ),
					'images'      => array(
						'display'   => $image['node']['display_url'],
						'thumbnail' => $image['node']['thumbnail_src']
					),
				);

				if ( count($data_images) >= $count )
				{
					break;
				}
			}

		} else {
			$data_json = json_decode( $codepages_response['body'], TRUE );

			foreach ( $data_json['data'] as $image )
			{
				$data_images[] = array(
					'id'          => $image['id'],
					'time'        => $image['created_time'],
					'like'        => $image['likes']['count'],
					'comment'     => $image['comments']['count'],
					'caption'     => !empty( $image['caption']['text'] ) ? preg_replace('/[^a-zA-Z0-9\-]/', ' ', $image['caption']['text']) : '',
					'link'        => $image['link'],
					'images'      => array(
						'display'   => $image['images']['standard_resolution']['url'],
						'thumbnail' => $image['images']['thumbnail']['url']
					),
				);

				if ( count($data_images) >= $count )
				{
					break;
				}
			}
		}

		if ( (($count - count($data_images)) > 0) && (count($data_images) % 12 == 0) && (count($data_images) > 0) && $method != 'username' )
		{
			$max_id = end( $data_images );
			$max_id = $max_id['id'];

			$next_images = $this->scrap_data( $username, $token, $method, ($count - 12), $max_id );

			if ( !is_wp_error( $next_images ) )
			{
				$data_images = array_merge( $data_images, $next_images );
			}
		}

		return $data_images;

	}

	return null;
}

function get_url( $username, $max_id )
{
		$username = str_replace( '@', '', $username );

		if ( empty( $max_id ) )
		{
				return 'https://www.instagram.com/' . $username;
		} else {
				return 'https://www.instagram.com/' . $username . '?max_id=' . $max_id;
		}
}

function images_only( $media_item ) {
	if ( $media_item['type'] == 'image' )
	return true;
	return false;
}
