<?php

$post_categories = get_terms("category");
$post_categories_array = array();
$post_categories_array[__("All Categories", 'cairo')] = "-";
foreach($post_categories as $post_category) {
  $post_categories_array[$post_category->name] =  $post_category->term_id;
}


// ==========================================================================================
// Categoy Posts Style
// ==========================================================================================

	vc_map( array(
		"name" 			=> esc_html__("Categoy Posts", 'cairo'),
		"base" 			=> "cairo_category_module",
		"class" 		=> "",
		"category" 		=> esc_html__("Cairo Theme", 'cairo'),
		"icon"      	=> "ti ti-layout",
		"description" 	=>esc_html__( 'Bulid Your Layout Posts Blog.','cairo'),
		"params"		=> array(
			array(
				"type" => "dropdown",
				"heading" => "Style",
				"param_name" => "style",
				"admin_label" => true,
        'weight' => 0,
				"value" => array(
					esc_html__("None Select", 'cairo') => "none",
					esc_html__("style 1", 'cairo') => "style1",
					esc_html__("style 2", 'cairo') => "style2",
					esc_html__("style 3", 'cairo') => "style3",
					esc_html__("style 4", 'cairo') => "style4",
					esc_html__("style 5", 'cairo') => "style5",
					esc_html__("style 6", 'cairo') => "style6",
					esc_html__("style 7", 'cairo') => "style7",
					esc_html__("style 8", 'cairo') => "style8",
					esc_html__("style 9", 'cairo') => "style9",
					esc_html__("style 10", 'cairo') => "styleten",
				),
				"description" => "This changes the layouts of the grids"
			),
			//Style 1
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'styleoneimage',
				'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_category_1.png',
				'dependency' => Array('element' => "style", 'value' => array('style1'))
			),
			//Style 2
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'styletwoimage',
				'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_category_2.png',
				'dependency' => Array('element' => "style", 'value' => array('style2'))
			),
			//Style 3
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylethereeimage',
				'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_category_3.png',
				'dependency' => Array('element' => "style", 'value' => array('style3'))
			),
			//Style 4
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylefourimage',
				'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_category_4.png',
				'dependency' => Array('element' => "style", 'value' => array('style4'))
			),
			//Style 5
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylefiveimage',
				'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_category_5.png',
				'dependency' => Array('element' => "style", 'value' => array('style5'))
			),
			//Style 6
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylesiximage',
				'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_category_6.png',
				'dependency' => Array('element' => "style", 'value' => array('style6'))
			),
			//Style 7
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylesevenimage',
				'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_category_7.png',
				'dependency' => Array('element' => "style", 'value' => array('style7'))
			),
			//Style 8
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'styleeightimage',
				'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_category_8.png',
				'dependency' => Array('element' => "style", 'value' => array('style8'))
			),
			//Style 9
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylesnineimage',
				'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_category_9.png',
				'dependency' => Array('element' => "style", 'value' => array('style9'))
			),
			//Style 10
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylestenimage',
				'value' => get_template_directory_uri().'/assets/images/admin/category_module/cairo_category_10.png',
				'dependency' => Array('element' => "style", 'value' => array('styleten'))
			),

			//Dark & light Style
			array(
				"type"					=> "toggle_checkbox",
				"class" 				=> "",
				"param_name" 		=> "darklight_onoff",
				"heading" 			=> esc_html__("Dark or light layout On/Off.", "cairo"),
				"description" 	=> esc_html__("You can on/off Dark or light layout.","cairo"),
				"value" 				=> "false",
				"options" 			=> array(
					"true" 	=> array(
							"label" => "",
							"on" => "Yes",
							"off" => "No",
						),
					),
			),

			//Column Style Layout
			array(
				'type'	=> 'dropdown',
				'heading'	=> 'Column Style',
				'param_name'	=> 'columnsection',
				'value' => array(
						esc_html__("None Select", 'cairo') => "none-select",
						esc_html__("Theree Column", 'cairo') => "style1",
						esc_html__("Four Column", 'cairo') => "style2",
				),
				'dependency' => Array('element' => "style", 'value' => array('style3','style5'))
			),

			//Author Images Settings
			array(
			"type" => "dropdown",
			"heading" => "Author Images Settings",
			"param_name" => "autherimgdisplay",
			"value" => array(
				esc_html__("None Select", 'cairo') => "none",
				'Show' => "show",
				'Hide' => "hide",
			),
			"description" => "Author Images Settings",
			'dependency' => Array('element' => "style", 'value' => array('style1','style2','style9'))
			),

			//Post Rating
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Show Post Review",'cairo'),
				"description" => esc_html__("You can on/off Post Review",'cairo'),
				"param_name" => "postreview",
				"value" => array(
					esc_html__("On", 'cairo') => 'on',
					esc_html__("Off", 'cairo') => 'off',
				),
				'std'   => 'off',
			),

			//Post desc. show/hide
			array(
			"type" => "dropdown",
			"heading" => "Post desc. show/hide.",
			"param_name" => "desdisplay",
			"value" => array(
				esc_html__("None Select", 'cairo') => "none",
				'Show' => "show",
				'Hide' => "hide",
			),
			"description" => "Post desc. show/hide.",
			'dependency' => Array('element' => "style", 'value' => array('style1','style2','style3','style4','style8','style9','styleten'))
			),

			//Subcategory show/hide
			array(
			"type" => "dropdown",
			"heading" => "Subcategory show/hide.",
			"param_name" => "subcategorydisplay",
			"value" => array(
				esc_html__("None Select", 'cairo') => "none",
				'Show' => "show",
				'Hide' => "hide",
			),
			"description" => "Subcategory show/hide.",
			'dependency' => Array('element' => "style", 'value' => array('style1','style3','style4'))
			),

			//Post meta show/hide
			array(
			"type" => "dropdown",
			"heading" => "Post meta show/hide.",
			"param_name" => "metadisplay",
			"value" => array(
				esc_html__("None Select", 'cairo') => "none",
				'Show' => "show",
				'Hide' => "hide",
			),
			"description" => "Post meta show/hide.",
			'dependency' => Array('element' => "style", 'value' => array('style1','style2','style3'))
			),

			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Title Text",'cairo'),
				'group' => esc_html__("Title Settings", 'cairo'),
				"description" => esc_html__("Title Block Text",'cairo'),
				"param_name" => "categorytitle",
				"value" => "",
			),
			array(
			"type" => "dropdown",
			"heading" => "Post Title Style",
			'group' => esc_html__("Title Settings", 'cairo'),
			"param_name" => "titlestyle",
			"value" => array(
				esc_html__("None Select", 'cairo') => "none",
				'Style1' => "style1",
				'Style2' => "style2",
				'Style3' => "style3",
				'Style4' => "style4",
				'Style5' => "style5",
				'Style6' => "style6",
				'Style7' => "style7",
			),
			"description" => "This changes style the block title",
			),

			//Post Count
			array(
				"type"			=>	"textfield",
				"class"			=>	"",
				"heading"		=>	esc_html__('Post Count', 'cairo'),
				'group' 		=> esc_html__("Category Filter", 'cairo'),
				"description"	=>  esc_html__('Enter Post Count', 'cairo'),
				"param_name"	=>	"postcount",
				"value"			=>	"",
				'dependency' => Array('element' => "style", 'value' => array('style4','style5','style3'))
			),
			//Pos Order By
			array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Post Order By",'cairo'),
			'group' => esc_html__("Category Filter", 'cairo'),
			"description" => esc_html__("Post Order By",'cairo'),
			"param_name" => "categoryorderby",
				"value" => array(
					esc_html__("None Select", 'cairo') => "none",
					esc_html__("Date", 'cairo') => 'date',
					esc_html__("Random", 'cairo') => 'rand',
					esc_html__("Comment Count", 'cairo') => 'comment_count',
				)
			),
			array(
				"type" => "dropdown",
				"heading" => "Post Source",
				'group' => esc_html__("Category Filter", 'cairo'),
				"param_name" => "source",
				"value" => array(
					'None Select' => 'none',
					'By Category' => 'by-category',
					'By Post ID' => 'by-id',
					'By Tag' => 'by-tag',
					'By Author' => 'by-author',
				),
				"admin_label" => true,
				"description" => "Select the source of the posts you'd like to show."
			),
			array(
				"type" => "dropdown",
				"heading" => "Post Categories",
				'group' => esc_html__("Category Filter", 'cairo'),
				"param_name" => "cat",
				"value" => $post_categories_array,
				"description" => "Which categories would you like to show?",
				"dependency" => Array('element' => "source", 'value' => array('by-category'))
			),
			//Exclude Category
			array(
				"type" => "textfield",
				"class" => "",
				'group' => esc_html__("Category Filter", 'cairo'),
				"heading" => esc_html__("Exclude Category",'cairo'),
				"description" => esc_html__("Enter exclude category id. Separate with commas 1,2,3 etc.",'cairo'),
				"param_name" => "excludecategory",
				"value" => "",
				"dependency" => Array('element' => "source", 'value' => array('by-category'))
			),
			//Exclude Post
			array(
				"type" => "textfield",
				"class" => "",
				'group' => esc_html__("Category Filter", 'cairo'),
				"heading" => esc_html__("Exclude Posts",'cairo'),
				"description" => esc_html__("Enter exclude posts(s) id. Separate with commas 1,2,3 etc.",'cairo'),
				"param_name" => "excludeposts",
				"value" => "",
				"dependency" => Array('element' => "source", 'value' => array('by-id'))
			),
			//Exclude Tag
			array(
				"type" => "textfield",
				"heading" => "Tag slugs",
				'group' => esc_html__("Category Filter", 'cairo'),
				"param_name" => "excludetag",
				"description" => "Enter the tag ID you would like to display seperated by comma",
				"dependency" => Array('element' => "source", 'value' => array('by-tag'))
			),
			//Exclude Author
			array(
				"type" => "textfield",
				"heading" => "Author IDs",
				'group' => esc_html__("Category Filter", 'cairo'),
				"param_name" => "author_ids",
				"description" => "Enter the Author IDs you would like to display seperated by comma",
				"dependency" => Array('element' => "source", 'value' => array('by-author'))
			),
		),
	));
