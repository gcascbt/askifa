<?php
/**
 *
 * Breaking News Style
 * @since 1.0.0
 * @version 1.0.0
 *
 */

function cairo_breaking_news( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'style'							=>	'',
			'source'						=>  '',
			'breakingtitle'			=>  '',
			'cat'								=>	'',
			'postid'						=>	'',
			'tagslugs'					=>	'',
			'authorids'					=>	'',
			'postcount'					=>	'',
			'breakingorderby'		=>	'',
			'excludeposts'			=>  '',
			'excludecategory'		=>  '',
			'excludetag'		  	=>  '',
		), $atts
	);

	$output = '';

  //Start Exclude category
	if( !empty( $atts['excludeposts'] ) ) :
		$excludepost = $atts['excludeposts'];
		$excludepost = explode( ',', $excludepost );
	else:
		$excludepost = "";
	endif;

	//Start Count Posts
	if( !empty( $atts['postcount'] ) ) :
		$postcount = $atts['postcount'];
	else:
		$postcount = "";
	endif;

	//Start Exclude Categoy
	if( !empty( $atts['excludecategory'] ) ) :
		$excludecategoy = $atts['excludecategory'];
		$excludecategoy = explode( ',', $excludecategoy );
	else:
		$excludecategoy = "";
	endif;

	//Start Exclude Tag
	if( !empty( $atts['excludetag'] ) ) :
		$excludetags = $atts['excludetag'];
		$excludetags = explode( ',', $excludetags );
	else:
		$excludetags = "";
	endif;

	//Start ID Posts
	if( !empty( $atts['postid'] ) ) :
		$bypostid = $atts['postid'];
		$bypostid = explode( ',', $bypostid );
	else:
		$bypostid = "";
	endif;

	//Start Category Order By
	if( !empty( $atts['breakingorderby'] ) ) :
		$breakingorderby = $atts['breakingorderby'];
	else:
		$breakingorderby = "";
	endif;

  // ==========================================================================================
  // Breaking News Style 1
  // ==========================================================================================

	if( strstr( $atts['style'], "style1" ) ) :

		$output .= '<div class="breaking-new-bar breaking-news-style1">';
		$output .= '<div class="breaking-bar">';
		//Start Section Title
		$postareatitle = $atts['breakingtitle'];
		if( !empty($postareatitle) ) :
			$output .= '
			<span class="title-news-ticker">'.$postareatitle.'</span>
			';
		else:
		endif;
		$output .= '<div class="breaking-style1 codepages-loading">';

		//Start Query Breaking Posts
		$breaking_one = array(
			'post__in'							=> $bypostid,
			'author'								=> $atts['authorids'],
			'posts_per_page' 				=> $postcount,
			'post_status'						=> 'publish',
			'orderby'  				    	=> $breakingorderby,
			'cat' 									=> $atts['cat'],
			'post__not_in' 					=> $excludepost,
			'category__not_in' 			=> $excludecategoy,
			'tag__not_in'						=> $excludetags,
			'ignore_sticky_posts' 	=> true,
			'post_type' 						=> 'post'
		);

		//Start Query
		$wp_query_args_breaking_posts = new WP_Query( $breaking_one );
		while ( $wp_query_args_breaking_posts->have_posts() ) :
		$wp_query_args_breaking_posts->the_post();;

    $output .= '<div class="item">';

		//Start Post Meta
    $post_information = '
    <span class="post-data"><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span>
		';

		//Start Loop Breaking News Post
		$output .= '
		<div class="title-trending-content">
			<h2 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h2>
			'.$post_information.'
		</div>
    ';
		$output .= '</div>';
    endwhile;
		wp_reset_postdata();

		$output .= '</div>';
		//Start Slide Nav
		$output .= '
		<div class="ticker-slide-nav">
			<div class="prev-arrow"></div>
			<div class="next-arrow"></div>
		</div>
		';
		$output .= '</div>';
		$output .= '</div>';
		return $output;

  // ==========================================================================================
  // Breaking News Style 2
  // ==========================================================================================

	elseif( strstr( $atts['style'], "style2" ) ) :

		$output .= '<div class="breaking-new-bar breaking-news-style2">';
		$output .= '<div class="breaking-bar">';
		//Start Section Title
		$postareatitle = $atts['breakingtitle'];
		if( !empty($postareatitle) ) :
			$output .= '
			<span class="title-news-ticker">'.$postareatitle.'</span>
			';
		else:
		endif;
		$output .= '</div>';
		$output .= '<div class="breaking-style2 codepages-loading">';

		//Start Query Breaking Posts
		$breaking_one = array(
			'post__in'							=> $bypostid,
			'author'								=> $atts['authorids'],
			'posts_per_page' 				=> $postcount,
			'post_status'						=> 'publish',
			'orderby'  				    	=> $breakingorderby,
			'cat' 									=> $atts['cat'],
			'post__not_in' 					=> $excludepost,
			'category__not_in' 			=> $excludecategoy,
			'tag__not_in'						=> $excludetags,
			'ignore_sticky_posts' 	=> true,
			'post_type' 						=> 'post'
		);

		//Start Query
		$wp_query_args_breaking_posts = new WP_Query( $breaking_one );
		while ( $wp_query_args_breaking_posts->have_posts() ) :
		$wp_query_args_breaking_posts->the_post();;

		//Start Get Category Posts
		$categories = get_the_category( get_the_ID() );
		$catname = $categories[0]->name;
		$class = strtolower($catname);
		$class = str_replace(' ', '-', $class);
		$class = sanitize_title($class);

		$categories_category = "";
		$categories_category = get_the_category( get_the_ID() );
		$categories_firstCategory = $categories_category[0]->cat_ID;

		$post_categories = '
		<div class="post-category category-bg-color">
			<ul>
				<li>
					<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
				</li>
			</ul>
		</div>
		';

		$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-thumb-three' );
		$image = '<figure class="post-image">';
		$image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
		$image .= '</figure>';


    $output .= '<div class="item">';

		//Start Post Meta
    $post_information = '
    <span class="post-data"><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span>
		';

		//Start Loop Breaking News Post
		$output .= '
		<div class="title-breaking-content">
			'. $post_categories .'
			'. $image . '
			<div class="post-detail">
				<h5 class="entry-title"><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h5>
				'.$post_information.'
			</div>
		</div>
    ';
		$output .= '</div>';
    endwhile;
		wp_reset_postdata();

		$output .= '</div>';
		//Start Slide Nav
		$output .= '
		<div class="ticker-slide-nav">
			<div class="prev-arrow"></div>
			<div class="next-arrow"></div>
		</div>
		';
		$output .= '</div>';
		return $output;

	endif;
}
add_shortcode("cairo_breaking_news_module", "cairo_breaking_news");
