<?php
// ==========================================================================================
// Gallery Moduel Element
// ==========================================================================================

vc_map( array(
  "name" 					=> esc_html__("Gallery Images", 'cairo'),
  "base" 					=> "codepages_gallery_module",
  "class" 				=> "",
  "category" 			=> esc_html__("Cairo Theme", 'cairo'),
  "icon"      		=> "ti ti-gallery",
  "description" 	=>esc_html__( 'Bulid Your Layout Posts Blog.','cairo'),
  "params"				=> array(
    array(
      "type" => "dropdown",
      "heading" =>  esc_html__("Gallery Style",'cairo'),
      "param_name" => "style",
      "admin_label" => true,
      "value" => array(
        esc_html__("None Select", 'cairo') => "none",
        esc_html__("Style 1", 'cairo') => "style1",
        esc_html__("Style 2", 'cairo') => "style2",
      ),
      "description" => "This changes the style of Gallery",
    ),
    array(
      "type" => "attach_images",
      "heading" =>  esc_html__("Select Images",'cairo'),
      "param_name" => "image",
      "description" => ""
    ),
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Extra Class", 'cairo'),
      "param_name" => "extra_class",
      "value" => "",
      "description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'cairo' ),
      'group' => esc_html__("Extra Settings", 'cairo'),
    ),
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Extra ID", 'cairo'),
      "param_name" => "extra_id",
      "value" => "",
      "description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a id name and then refer to it in your css file.", 'cairo' ),
      'group' => esc_html__("Extra Settings", 'cairo'),
    ),
  ),
));
