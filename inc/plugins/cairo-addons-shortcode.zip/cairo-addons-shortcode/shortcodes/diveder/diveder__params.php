<?php
// ==========================================================================================
// Divider Element
// ==========================================================================================

vc_map( array(
  "name" 					=> esc_html__("Divider", 'cairo'),
  "base" 					=> "codepages_divider_module",
  "class" 				=> "",
  "category" 			=> esc_html__("Cairo Theme", 'cairo'),
  "icon"      		=> "ti ti-more-alt	",
  "description" 	=>esc_html__( 'Bulid Your Layout Posts Blog.','cairo'),
  "params"				=> array(
    array(
      "type" => "dropdown",
      "heading" =>  esc_html__("Style Divider",'cairo'),
      "param_name" => "style",
      "admin_label" => true,
      "value" => array(
        esc_html__("None Select", 'cairo') => "none",
        esc_html__("style 1", 'cairo') => "style1",
        esc_html__("style 2", 'cairo') => "style2",
        esc_html__("style 3", 'cairo') => "style3",
        esc_html__("style 4", 'cairo') => "style4",
        esc_html__("style 5", 'cairo') => "style5",
        esc_html__("style 6", 'cairo') => "style6",
        esc_html__("style 7", 'cairo') => "style7",
        esc_html__("style 8", 'cairo') => "style8",
        esc_html__("style 9", 'cairo') => "style9",
      ),
      "description" => "This changes the layouts of the Divider",
    ),
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Extra Class", 'cairo'),
      "param_name" => "extra_class",
      "value" => "",
      "description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'cairo' ),
      'group' => esc_html__("Extra Settings", 'cairo'),
    ),
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Extra ID", 'cairo'),
      "param_name" => "extra_id",
      "value" => "",
      "description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a id name and then refer to it in your css file.", 'cairo' ),
      'group' => esc_html__("Extra Settings", 'cairo'),
    ),
  ),
));
