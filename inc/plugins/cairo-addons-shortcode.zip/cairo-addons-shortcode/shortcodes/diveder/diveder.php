<?php
/**
 *
 * Divider Style
 * @since 1.0.0
 * @version 1.0.0
 *
 */

function codepages_divider( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'style'							=>	'',
			'extra_class'				=>  '',
			'extra_id'					=>  '',
		), $atts
	);

	$output = '';

	$modulestyle 				= $atts['style'];
	$blockclass 				= $atts['extra_class'];
	$blockid    				= $atts['extra_id'];

  // ==========================================================================================
  // Module Divider Style
  // ==========================================================================================

	$output .= '<div id="codepages-divider" class="codepages-divider '.$blockclass.'">';
		$output .= '<div class="codepages-divider-'.$modulestyle.'"></div>';
	$output .= '</div>';;
	return $output;

}
add_shortcode("codepages_divider_module", "codepages_divider");
