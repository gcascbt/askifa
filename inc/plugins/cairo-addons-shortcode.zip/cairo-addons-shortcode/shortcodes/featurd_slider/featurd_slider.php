<?php
/**
 *
 * Featurd Slider Style
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function codepages_featurd_slider( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'style'							=>	'',
			'postcount'					=>	'',
			'excludeposts'			=>  '',
			'excludecategory'		=>  '',
			'excludetag'				=>  '',
			'featuredorderby'		=>  '',
			'postreview'				=>  '',
			'source'						=>  '',
			'postid'						=>	'',
			'posttag'						=>	'',
			'cat'								=>	'',
			'authorids'					=>	'',
		), $atts
	);

	$output = '';

	//Start Exclude Posts
	if( !empty( $atts['excludeposts'] ) ) :
		$excludepost = $atts['excludeposts'];
		$excludepost = explode( ',', $excludepost );
	else:
		$excludepost = "";
	endif;

	//Start Count Posts
	if( !empty( $atts['postcount'] ) ) :
		$postcount = $atts['postcount'];
	else:
		$postcount = "";
	endif;

	//Start Exclude Category
	if( !empty( $atts['excludecategory'] ) ) :
		$excludecategoy = $atts['excludecategory'];
		$excludecategoy = explode( ',', $excludecategoy );
	else:
		$excludecategoy = "";
	endif;

	//Start Exclude Tag
	if( !empty( $atts['excludetag'] ) ) :
		$excludetags = $atts['excludetag'];
		$excludetags = explode( ',', $excludetags );
	else:
		$excludetags = "";
	endif;

	//Start ID Posts
	if( !empty( $atts['postid'] ) ) :
		$bypostid = $atts['postid'];
		$bypostid = explode( ',', $bypostid );
	else:
		$bypostid = "";
	endif;

	//Start TAG Posts
	if( !empty( $atts['posttag'] ) ) :
		$byposttag = $atts['posttag'];
		$byposttag = explode( ',', $byposttag );
	else:
		$byposttag = "";
	endif;

	//Start Post Order By
  if( !empty( $atts['featuredorderby'] ) ) :
  	$featuredorderbys = $atts['featuredorderby'];
  else:
  	$featuredorderbys = "";
  endif;

  // ==========================================================================================
  // Featurd Slider Style 1
  // ==========================================================================================

	if( strstr( $atts['style'], "style1" ) ) :

 		$output .= '<div class="featured-post-slider featured-style1">';
		$output .= '<div class="featured-block">';
		$output .= '<ul class="featured-slider-posts featured-style-1 codepages-loading">';

		//Start Query Featurd Posts
		$featured_one = array(
			'post__in'							=> $bypostid,
			'author'								=> $atts['authorids'],
			'posts_per_page' 				=> $postcount,
			'post_status'						=> 'publish',
			'orderby'  				    	=> $featuredorderbys,
			'cat' 									=> $atts['cat'],
			'post__not_in' 					=> $excludepost,
			'category__not_in' 			=> $excludecategoy,
			'tag__not_in'						=> $excludetags,
			'ignore_sticky_posts' 	=> true,
			'post_type' 						=> 'post'
		);

		if ( $atts['source'] == 'by-tag') {
			$featured_one = wp_parse_args(
				array(
					'tag__in' 	=> explode(',', $atts['posttag']),
				)
			, $featured_one );
		}

    $i = 0;
    $output .= '<li><div class="featured-posts">';

		//Start Query
		$wp_query_args_latest_posts = new WP_Query( $featured_one );
		while ( $wp_query_args_latest_posts->have_posts() ) :
		$wp_query_args_latest_posts->the_post();$i++;

		//Start Get Images Posts
    if ($i % 4 == 1) {
        $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-medium-tow' );
        $image = '<figure class="post-image">';
        $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
        $image .= '</figure>';
    }
    elseif ($i % 4 == 2) {
        $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-small-one' );
        $image = '<figure class="post-image">';
        $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
        $image .= '</figure>';
    }
    elseif ($i % 4 == 3 || $i % 4 == 0) {
        $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-small-three' );
        $image = '<figure class="post-image">';
        $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
        $image .= '</figure>';
    }

		//Start Get Category Posts
		$categories = get_the_category( get_the_ID() );
		$catname = $categories[0]->name;
		$class = strtolower($catname);
		$class = str_replace(' ', '-', $class);
		$class = sanitize_title($class);

		$categories_category = "";
		$categories_category = get_the_category( get_the_ID() );
		$categories_firstCategory = $categories_category[0]->cat_ID;

		$post_categories = '
		<div class="post-category category-bg-color">
			<ul>
				<li>
					<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
				</li>
			</ul>
		</div>
		';

		//Start Get Meta Posts
	  $views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();

		if ( ot_get_option('post_view_count') == 'on' )  {
			$post_view_count = '<li class="post-views"><span><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</span></li>';
		} else {
			$post_view_count = '';
		}

    if ($i % 4 == 1 || $i % 4 == 2 ) {
    $post_information = '
    '.$post_view_count.'
    <li class="post-data"><span><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span></li>
    <li class="post-comment"><span><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</span></li>
		';

		$title_post = '<h2><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h2>';
    }
    elseif ($i % 4 == 3 || $i % 4 == 0 ) {
    $post_information = '
      '.$post_view_count.'
      <li class="post-data"><span><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span></li>
    ';

		$title_post = '<h4><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h4>';
    }

		//Start Post Rating
		$id = get_the_ID();
		if ($atts['postreview']=='on') :
			if(! get_post_meta($id, 'review_score', true)) :
				$rating_number = "";
			else:
				$ratings_count = get_post_meta($id, 'review_score', true);
				$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
			endif;
		else:
			$rating_number = "";
		endif;

    //Start Loop Posts
    if($i % 4 == 1) {
    $output .= '<div class="col-md-6 featured-blocks block-left"><div class="row">';
    }
    if($i % 4 == 2) {
    $output .= '<div class="col-md-6 featured-blocks block-right-larg"><div class="row">';
    }
    if($i % 4 == 3) {
    $output .= '<div class="col-md-6 featured-blocks block-right-small"><div class="row">';
    }
    if ($i % 4 == 1 || $i % 4 == 2){
    $output .= '<div class="col-md-12 col-sm-12 col-xs-12"><div class="featured-posts-larg">';
    }
    elseif ($i % 4 == 3 || $i % 4 == 0) {
    $output .= '<div class="col-md-6 col-sm-12 col-xs-12"><div class="featured-posts-small">';
    }
		$output .= '
    <article class="post post-overlay">
      <div class="featured-slider">
        '. $image . '
  			'.$post_categories.'
				'.$rating_number.'
        <div class="post-detail">
          <div class="post-title">
						'.$title_post.'
          </div>
    			<div class="meta-slider-content">
    				<ul>
    					'.$post_information.'
    				</ul>
          </div>
        </div>
      </div>
    </article>
    ';
    if ($i % 1== 0) {
      $output .= '</div></div>';
    }
    if($i % 4 == 1) {
      $output .= '</div></div>';
    }
    if($i % 4 == 2) {
      $output .= '</div></div>';
    }
    if($i % 4 == 0) {
      $output .= '</div></div>';
    }

    if($i % 4== 0 && $i < $postcount-1) { $output .= '</div><li><div class="featured-posts">';}
    ; endwhile;
    $output .= '</div></li>';
		wp_reset_postdata();

		$output .= '</ul>';
		$output .= '</div>';
		$output .= '</div>';
		return $output;

  // ==========================================================================================
  // Featurd Slider Style 2
  // ==========================================================================================

	elseif( strstr( $atts['style'], "style2" ) ) :

	  $output .= '<div class="featured-post-slider featured-style2">';
		$output .= '<div class="featured-block">';
		$output .= '<ul class="featured-slider-posts featured-style-2 codepages-loading">';

		//Start Query Featurd Posts
		$featured_one = array(
			'post__in'							=> $bypostid,
			'author'								=> $atts['authorids'],
			'posts_per_page' 				=> $postcount,
			'post_status'						=> 'publish',
			'orderby'  				    	=> 'date',
			'cat' 									=> $atts['cat'],
			'post__not_in' 					=> $excludepost,
			'category__not_in' 			=> $excludecategoy,
			'tag__not_in'						=> $excludetags,
			'ignore_sticky_posts' 	=> true,
			'post_type' 						=> 'post'
		);

		if ( $atts['source'] == 'by-tag') {
			$featured_one = wp_parse_args(
				array(
					'tag__in' 	=> explode(',', $atts['posttag']),
				)
			, $featured_one );
		}

	  $i = 0;
	  $output .= '<li><div class="featured-posts">';

		//Start Query
		$wp_query_args_latest_posts = new WP_Query( $featured_one );
		while ( $wp_query_args_latest_posts->have_posts() ) :
		$wp_query_args_latest_posts->the_post();$i++;

		//Start Get Images Posts
	  if ($i % 5 == 1 || $i % 5 == 2) {
	      $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-medium-four' );
	      $image = '<figure class="post-image">';
	      $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
	      $image .= '</figure>';
	  }
	  elseif ( $i % 5 == 3 || $i % 5 == 4 || $i % 5 == 0) {
	      $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-small-tow' );
	      $image = '<figure class="post-image">';
	      $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
	      $image .= '</figure>';
	  }

		//Start Get Category Posts
		$categories = get_the_category( get_the_ID() );
		$catname = $categories[0]->name;
		$class = strtolower($catname);
		$class = str_replace(' ', '-', $class);
		$class = sanitize_title($class);

		$categories_category = "";
		$categories_category = get_the_category( get_the_ID() );
		$categories_firstCategory = $categories_category[0]->cat_ID;

		$post_categories = '
		<div class="post-category category-bg-color">
			<ul>
				<li>
					<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
				</li>
			</ul>
		</div>
		';

		//Start Get Meta Posts
	  $views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();

		if ( ot_get_option('post_view_count') == 'on' )  {
			$post_view_count = '<li class="post-views"><span><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</span></li>';
		} else {
			$post_view_count = '';
		}

	  if ($i % 5 == 1 || $i % 5 == 2) {
	  $post_information = '
	  '.$post_view_count.'
	  <li class="post-data"><span><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span></li>
	  <li class="post-comment"><span><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</span></li>
		';
		$title_post = '<h2><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h2>';
	  }
	  elseif ( $i % 5 == 3 || $i % 5 == 4 || $i % 5 == 0) {
	  $post_information = '
	    '.$post_view_count.'
	    <li class="post-data"><span><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span></li>
	  ';
		$title_post = '<h4><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h4>';
	  }

		//Start Post Rating
		$id = get_the_ID();
		if ($atts['postreview']=='on') :
			if(! get_post_meta($id, 'review_score', true)) :
				$rating_number = "";
			else:
				$ratings_count = get_post_meta($id, 'review_score', true);
				$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
			endif;
		else:
			$rating_number = "";
		endif;

		//Start Loop Posts
	  if($i % 5 == 1) {
	  $output .= '<div class="col-md-12 featured-blocks block-top-larg"><div class="row">';
	  }
	  if($i % 5 == 3) {
	  $output .= '<div class="col-md-12 featured-blocks block-bottom-small"><div class="row">';
	  }
	  if ($i % 5 == 1 || $i % 5 == 2){
	  $output .= '<div class="col-md-6 col-sm-12 col-xs-12"><div class="featured-posts-larg">';
	  }
	  elseif ( $i % 5 == 3 || $i % 5 == 4 || $i % 5 == 0) {
	  $output .= '<div class="col-md-4 col-sm-12 col-xs-12"><div class="featured-posts-small">';
	  }
		$output .= '
	  <article class="post post-overlay">
	    <div class="featured-slider">
	      '. $image . '
				'.$rating_number.'
	      <div class="post-detail">
	        '.$post_categories.'
	        <div class="post-title">
	          '.$title_post.'
	        </div>
	  			<div class="meta-slider-content">
	  				<ul>
	  					'.$post_information.'
	  				</ul>
	        </div>
	      </div>
	    </div>
	  </article>
	  ';
	  if ($i % 1== 0) {
	    $output .= '</div></div>';
	  }
	  if($i % 5 == 2) {
	    $output .= '</div></div>';
	  }
	  if($i % 5 == 0) {
	    $output .= '</div></div>';
	  }

	  if($i % 5== 0 && $i < $postcount-1) { $output .= '</div><li><div class="featured-posts">';}
	  ; endwhile;
	  $output .= '</div></li>';
		wp_reset_postdata();

		$output .= '</ul>';
		$output .= '</div>';
		$output .= '</div>';
		return $output;

  // ==========================================================================================
  // Featurd Slider Style 3
  // ==========================================================================================

	elseif( strstr( $atts['style'], "style3" ) ) :

    $output .= '<div class="featured-post-slider featured-style3">';
  	$output .= '<div class="featured-block">';
  	$output .= '<ul class="featured-slider-posts featured-style-3 codepages-loading">';

		//Start Query Featurd Posts
		$featured_one = array(
			'post__in'							=> $bypostid,
			'author'								=> $atts['authorids'],
			'posts_per_page' 				=> $postcount,
			'post_status'						=> 'publish',
			'orderby'  				    	=> 'date',
			'cat' 									=> $atts['cat'],
			'post__not_in' 					=> $excludepost,
			'category__not_in' 			=> $excludecategoy,
			'tag__not_in'						=> $excludetags,
			'ignore_sticky_posts' 	=> true,
			'post_type' 						=> 'post'
		);

		if ( $atts['source'] == 'by-tag') {
			$featured_one = wp_parse_args(
				array(
					'tag__in' 	=> explode(',', $atts['posttag']),
				)
			, $featured_one );
		}

    $i = 0;
    $output .= '<li><div class="featured-posts">';

    //Start Query
  	$wp_query_args_latest_posts = new WP_Query( $featured_one );
  	while ( $wp_query_args_latest_posts->have_posts() ) :
  	$wp_query_args_latest_posts->the_post();$i++;

		//Start Get Images Posts
    if ($i % 5 == 1) {
        $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-medium-tow' );
        $image = '<figure class="post-image">';
        $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
        $image .= '</figure>';
    }
    elseif ($i % 5 == 2 || $i % 5 == 3 || $i % 5 == 4 || $i % 5 == 0) {
        $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-small-three' );
        $image = '<figure class="post-image">';
        $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
        $image .= '</figure>';
    }


    //Start Get Category Posts
  	$categories = get_the_category( get_the_ID() );
  	$catname = $categories[0]->name;
  	$class = strtolower($catname);
  	$class = str_replace(' ', '-', $class);
  	$class = sanitize_title($class);

  	$categories_category = "";
  	$categories_category = get_the_category( get_the_ID() );
  	$categories_firstCategory = $categories_category[0]->cat_ID;

  	$post_categories = '
  	<div class="post-category category-bg-color">
  		<ul>
  			<li>
  				<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
  			</li>
  		</ul>
  	</div>
  	';

		//Start Get Meta Posts
	  $views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();

		if ( ot_get_option('post_view_count') == 'on' )  {
			$post_view_count = '<li class="post-views"><span><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</span></li>';
		} else {
			$post_view_count = '';
		}

    if ($i % 5 == 1) {
    $post_information = '
    '.$post_view_count.'
    <li class="post-data"><span><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span></li>
    <li class="post-comment"><span><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</span></li>
  	';

		$title_post = '<h2><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h2>';
    }
    elseif ($i % 5 == 2 || $i % 5 == 3 || $i % 5 == 4 || $i % 5 == 0) {
    $post_information = '
      '.$post_view_count.'
      <li class="post-data"><span><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span></li>
    ';

		$title_post = '<h4><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h4>';
    }

		//Start Post Rating
		$id = get_the_ID();
		if ($atts['postreview']=='on') :
			if(! get_post_meta($id, 'review_score', true)) :
				$rating_number = "";
			else:
				$ratings_count = get_post_meta($id, 'review_score', true);
				$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
			endif;
		else:
			$rating_number = "";
		endif;

    //Start Loop Posts
    if($i % 5 == 1) {
    $output .= '<div class="col-md-6 featured-blocks block-left-larg"><div class="row">';
    }
    if($i % 5 == 2) {
    $output .= '<div class="col-md-6 featured-blocks block-right-small"><div class="row">';
    }
    if ($i % 5 == 1) {
    $output .= '<div class="col-md-12 col-sm-12 col-xs-12"><div class="featured-posts-larg">';
    }
    elseif ($i % 5 == 2 || $i % 5 == 3 || $i % 5 == 4 || $i % 5 == 0) {
    $output .= '<div class="col-md-6 col-sm-12 col-xs-12"><div class="featured-posts-small">';
    }
  	$output .= '
    <article class="post post-overlay">
      <div class="featured-slider">
        '. $image . '
				'.$rating_number.'
        <div class="post-detail">
          '.$post_categories.'
          <div class="post-title">
            '.$title_post.'
          </div>
    			<div class="meta-slider-content">
    				<ul>
    					'.$post_information.'
    				</ul>
          </div>
        </div>
      </div>
    </article>
    ';

    if ($i % 1== 0) {
      $output .= '</div></div>';
    }
    if($i % 5 == 1) {
      $output .= '</div></div>';
    }
    if($i % 5 == 0) {
      $output .= '</div></div>';
    }

    if($i % 5== 0 && $i < $postcount-1) { $output .= '</div><li><div class="featured-posts">';}
    ; endwhile;
    $output .= '</div></li>';
  	wp_reset_postdata();

  	$output .= '</ul>';
  	$output .= '</div>';
  	$output .= '</div>';
  	return $output;


  // ==========================================================================================
  // Featurd Slider Style 4
  // ==========================================================================================

	elseif (strstr( $atts['style'], "style4" )) :

    $output .= '<div class="featured-post-slider featured-style4">';
  	$output .= '<div class="featured-block">';
  	$output .= '<ul class="featured-slider-posts featured-style-4 codepages-loading">';

		//Start Query Featurd Posts
		$featured_one = array(
		  'post__in'							=> $bypostid,
		  'author'								=> $atts['authorids'],
		  'posts_per_page' 				=> $postcount,
		  'post_status'						=> 'publish',
		  'orderby'  				    	=> 'date',
		  'cat' 									=> $atts['cat'],
		  'post__not_in' 					=> $excludepost,
		  'category__not_in' 			=> $excludecategoy,
		  'tag__not_in'						=> $excludetags,
		  'ignore_sticky_posts' 	=> true,
		  'post_type' 						=> 'post'
		);

		if ( $atts['source'] == 'by-tag') {
			$featured_one = wp_parse_args(
				array(
					'tag__in' 	=> explode(',', $atts['posttag']),
				)
			, $featured_one );
		}

    $i = 0;
    $output .= '<li><div class="featured-posts">';

    //Start Query
  	$wp_query_args_latest_posts = new WP_Query( $featured_one );
  	while ( $wp_query_args_latest_posts->have_posts() ) :
  	$wp_query_args_latest_posts->the_post();$i++;

		//Start Get Images Posts
    if ($i % 5 == 3) {
        $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-medium-tow' );
        $image = '<figure class="post-image">';
        $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
        $image .= '</figure>';
    }
    elseif ($i % 5 == 1 || $i % 5 == 2 || $i % 5 == 4 || $i % 5 == 0) {
        $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-small-three' );
        $image = '<figure class="post-image">';
        $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
        $image .= '</figure>';
    }

    //Start Get Category Posts
  	$categories = get_the_category( get_the_ID() );
  	$catname = $categories[0]->name;
  	$class = strtolower($catname);
  	$class = str_replace(' ', '-', $class);
  	$class = sanitize_title($class);

  	$categories_category = "";
  	$categories_category = get_the_category( get_the_ID() );
  	$categories_firstCategory = $categories_category[0]->cat_ID;

  	$post_categories = '
  	<div class="post-category category-bg-color">
  		<ul>
  			<li>
  				<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
  			</li>
  		</ul>
  	</div>
  	';

		//Start Get Meta Posts
	  $views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();

		if ( ot_get_option('post_view_count') == 'on' )  {
			$post_view_count = '<li class="post-views"><span><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</span></li>';
		} else {
			$post_view_count = '';
		}

    if ($i % 5 == 3) {
    $post_information = '
    '.$post_view_count.'
    <li class="post-data"><span><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span></li>
    <li class="post-comment"><span><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</span></li>
  	';

		$title_post = '<h2><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h2>';
    }
    elseif ($i % 5 == 1 || $i % 5 == 2 || $i % 5 == 4 || $i % 5 == 0) {
    $post_information = '
      '.$post_view_count.'
      <li class="post-data"><span><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span></li>
    ';

		$title_post = '<h4><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h4>';
    }

		//Start Post Rating
		$id = get_the_ID();
		if ($atts['postreview']=='on') :
			if(! get_post_meta($id, 'review_score', true)) :
				$rating_number = "";
			else:
				$ratings_count = get_post_meta($id, 'review_score', true);
				$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
			endif;
		else:
			$rating_number = "";
		endif;

    //Start Loop Posts
    if($i % 5 == 1) {
    $output .= '<div class="featured-blocks block-left-small col-md-3 col-sm-12 col-xs-12 ">';
    }
    if($i % 5 == 4) {
    $output .= '<div class="featured-blocks block-right-small col-md-3 col-sm-12 col-xs-12">';
    }
    if($i % 5 == 3) {
    $output .= '<div class="featured-blocks block-center-larg col-md-6 col-sm-12 col-xs-12">';
    }
    if($i % 5 == 3) {
    $output .= '<div class="col-md-12 col-sm-12 col-xs-12"><div class="featured-posts-larg">';
    }
    elseif ($i % 5 == 1 || $i % 5 == 2 || $i % 5 == 4 || $i % 5 == 0) {
    $output .= '<div class="col-md-12 col-sm-12 col-xs-12"><div class="featured-posts-small">';
    }
  	$output .= '
    <article class="post post-overlay">
      <div class="featured-slider">
        '. $image . '
				'.$rating_number.'
        <div class="post-detail">
          '.$post_categories.'
          <div class="post-title">
            '.$title_post.'
          </div>
    			<div class="meta-slider-content">
    				<ul>
    					'.$post_information.'
    				</ul>
          </div>
        </div>
      </div>
    </article>
    ';

    if ($i % 1== 0) {
      $output .= '</div></div>';
    }
    if ($i % 5 == 3) {
      $output .= '</div>';
    }
    if ($i % 5 == 2 || $i % 5 == 0) {
      $output .= '</div>';
    }

    if($i % 5== 0 && $i < $postcount-1) { $output .= '</div><li><div class="featured-posts">';}
    ; endwhile;
    $output .= '</div></li>';
  	wp_reset_postdata();

  	$output .= '</ul>';
  	$output .= '</div>';
  	$output .= '</div>';
  	return $output;


  // ==========================================================================================
  // Featurd Slider Style 5
  // ==========================================================================================

	elseif (strstr( $atts['style'], "style5" )) :

    $output .= '<div class="featured-post-slider featured-style5">';
  	$output .= '<div class="featured-block">';
  	$output .= '<ul class="featured-slider-posts featured-style-5 codepages-loading">';

		//Start Query Featurd Posts
		$featured_one = array(
		  'post__in'							=> $bypostid,
		  'author'								=> $atts['authorids'],
		  'posts_per_page' 				=> $postcount,
		  'post_status'						=> 'publish',
		  'orderby'  				    	=> 'date',
		  'cat' 									=> $atts['cat'],
		  'post__not_in' 					=> $excludepost,
		  'category__not_in' 			=> $excludecategoy,
		  'tag__not_in'						=> $excludetags,
		  'ignore_sticky_posts' 	=> true,
		  'post_type' 						=> 'post'
		);

		if ( $atts['source'] == 'by-tag') {
			$featured_one = wp_parse_args(
				array(
					'tag__in' 	=> explode(',', $atts['posttag']),
				)
			, $featured_one );
		}

    $i = 0;
    $output .= '<li><div class="featured-posts">';

    //Start Query
  	$wp_query_args_latest_posts = new WP_Query( $featured_one );
  	while ( $wp_query_args_latest_posts->have_posts() ) :
  	$wp_query_args_latest_posts->the_post();$i++;

		//Start Get Images Posts
    if ($i % 3 == 1) {
        $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-large-three' );
        $image = '<figure class="post-image">';
        $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
        $image .= '</figure>';
    }
    elseif ($i % 3 == 2 || $i % 3 == 0) {
        $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-large-three' );
        $image = '<figure class="post-image">';
        $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
        $image .= '</figure>';
    }

    //Start Get Category Posts
  	$categories = get_the_category( get_the_ID() );
  	$catname = $categories[0]->name;
  	$class = strtolower($catname);
  	$class = str_replace(' ', '-', $class);
  	$class = sanitize_title($class);

  	$categories_category = "";
  	$categories_category = get_the_category( get_the_ID() );
  	$categories_firstCategory = $categories_category[0]->cat_ID;

  	$post_categories = '
  	<div class="post-category category-bg-color">
  		<ul>
  			<li>
  				<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
  			</li>
  		</ul>
  	</div>
  	';

		//Start Get Meta Posts
	  $views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();

		if ( ot_get_option('post_view_count') == 'on' )  {
			$post_view_count = '<li class="post-views"><span><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</span></li>';
		} else {
			$post_view_count = '';
		}

    if ($i % 3 == 1) {
    $post_information = '
    '.$post_view_count.'
    <li class="post-data"><span><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span></li>
    <li class="post-comment"><span><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</span></li>
  	';

		$title_post = '<h2><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h2>';
    }
    elseif ($i % 3 == 2 || $i % 3 == 0) {
    $post_information = '
      '.$post_view_count.'
      <li class="post-data"><span><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span></li>
    ';

		$title_post = '<h4><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h4>';
    }

		//Start Post Rating
		$id = get_the_ID();
		if ($atts['postreview']=='on') :
			if(! get_post_meta($id, 'review_score', true)) :
				$rating_number = "";
			else:
				$ratings_count = get_post_meta($id, 'review_score', true);
				$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
			endif;
		else:
			$rating_number = "";
		endif;

    //Start Loop Posts
    if($i % 3 == 1) {
    $output .= '<div class="featured-blocks block-left-larg col-md-8 col-sm-12 col-xs-12 ">';
    }
    if($i % 3 == 2) {
    $output .= '<div class="featured-blocks block-right-small col-md-4 col-sm-12 col-xs-12 ">';
    }
    if ($i % 3 == 1) {
    $output .= '<div class="featured-posts-larg col-md-12 col-sm-12 col-xs-12">';
    }
    elseif ($i % 3 == 2 || $i % 3 == 0) {
    $output .= '<div class="featured-posts-small col-md-12 col-sm-12 col-xs-12">';
    }
  	$output .= '
    <article class="post post-overlay">
      <div class="featured-slider">
        '. $image . '
				'.$rating_number.'
        <div class="post-detail">
          '.$post_categories.'
          <div class="post-title">
            '.$title_post.'
          </div>
    			<div class="meta-slider-content">
    				<ul>
    					'.$post_information.'
    				</ul>
          </div>
        </div>
      </div>
    </article>
    ';

    if ($i % 1== 0) {
      $output .= '</div>';
    }
    if ($i % 3 == 1) {
      $output .= '</div>';
    }
    if ($i % 3 == 0) {
      $output .= '</div>';
    }

    if($i % 3== 0 && $i < $postcount-1) { $output .= '</div><li><div class="featured-posts">';}
    ; endwhile;
    $output .= '</div></li>';
  	wp_reset_postdata();

  	$output .= '</ul>';
  	$output .= '</div>';
  	$output .= '</div>';
  	return $output;


  // ==========================================================================================
  // Featurd Slider Style 6
  // ==========================================================================================

	elseif (strstr( $atts['style'], "style6" )) :

    $output .= '<div class="featured-post-slider featured-style6">';
  	$output .= '<div class="featured-block">';
  	$output .= '<ul class="featured-slider-posts featured-style-6 codepages-loading">';

		//Start Query Featurd Posts
		$featured_one = array(
		  'post__in'							=> $bypostid,
		  'author'								=> $atts['authorids'],
		  'posts_per_page' 				=> $postcount,
		  'post_status'						=> 'publish',
		  'orderby'  				    	=> 'date',
		  'cat' 									=> $atts['cat'],
		  'post__not_in' 					=> $excludepost,
		  'category__not_in' 			=> $excludecategoy,
		  'tag__not_in'						=> $excludetags,
		  'ignore_sticky_posts' 	=> true,
		  'post_type' 						=> 'post'
		);

		if ( $atts['source'] == 'by-tag') {
			$featured_one = wp_parse_args(
				array(
					'tag__in' 	=> explode(',', $atts['posttag']),
				)
			, $featured_one );
		}

		//Start Query
  	$wp_query_args_latest_posts = new WP_Query( $featured_one );
  	while ( $wp_query_args_latest_posts->have_posts() ) :
  	$wp_query_args_latest_posts->the_post();

    //Start Get Images Posts
    $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-large-one' );
    $image = '<figure class="post-image">';
    $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
    $image .= '</figure>';

    //Start Get Category Posts
  	$categories = get_the_category( get_the_ID() );
  	$catname = $categories[0]->name;
  	$class = strtolower($catname);
  	$class = str_replace(' ', '-', $class);
  	$class = sanitize_title($class);

  	$categories_category = "";
  	$categories_category = get_the_category( get_the_ID() );
  	$categories_firstCategory = $categories_category[0]->cat_ID;

  	$post_categories = '
  	<div class="post-category category-bg-color">
  		<ul>
  			<li>
  				<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
  			</li>
  		</ul>
  	</div>
  	';

		//Start Get Meta Posts
	  $views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();

		if ( ot_get_option('post_view_count') == 'on' )  {
			$post_view_count = '<li class="post-views"><span><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</span></li>';
		} else {
			$post_view_count = '';
		}

    $post_information = '
    '.$post_view_count.'
    <li class="post-data"><span><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span></li>
    <li class="post-comment"><span><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</span></li>
  	';

		//Start Post Rating
		$id = get_the_ID();
		if ($atts['postreview']=='on') :
			if(! get_post_meta($id, 'review_score', true)) :
				$rating_number = "";
			else:
				$ratings_count = get_post_meta($id, 'review_score', true);
				$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
			endif;
		else:
			$rating_number = "";
		endif;

    //Start Loop Posts
  	$output .= '
    <li>
    <div class="featured-posts">
      <article class="post post-overlay">
        <div class="featured-slider">
          '. $image . '
					'.$rating_number.'
          <div class="post-detail">
            '.$post_categories.'
            <div class="post-title">
              <h2><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h2>
            </div>
      			<div class="meta-slider-content">
      				<ul>
      					'.$post_information.'
      				</ul>
            </div>
          </div>
        </div>
      </article>
    </div>
    </li>
    ';
    ; endwhile;
  	wp_reset_postdata();

  	$output .= '</ul>';
  	$output .= '</div>';
  	$output .= '</div>';
  	return $output;

  // ==========================================================================================
  // Featurd Slider Style 7
  // ==========================================================================================

	elseif (strstr( $atts['style'], "style7" )) :

    $output .= '<div class="featured-post-slider featured-style7">';
  	$output .= '<div class="featured-block">';
  	$output .= '<ul class="featured-slider-posts featured-style-7 codepages-loading">';

		//Start Query Featurd Posts
		$featured_one = array(
		  'post__in'							=> $bypostid,
		  'author'								=> $atts['authorids'],
		  'posts_per_page' 				=> $postcount,
		  'post_status'						=> 'publish',
		  'orderby'  				    	=> 'date',
		  'cat' 									=> $atts['cat'],
		  'post__not_in' 					=> $excludepost,
		  'category__not_in' 			=> $excludecategoy,
		  'tag__not_in'						=> $excludetags,
		  'ignore_sticky_posts' 	=> true,
		  'post_type' 						=> 'post'
		);

		if ( $atts['source'] == 'by-tag') {
			$featured_one = wp_parse_args(
				array(
					'tag__in' 	=> explode(',', $atts['posttag']),
				)
			, $featured_one );
		}

		//Start Query
  	$wp_query_args_latest_posts = new WP_Query( $featured_one );
  	while ( $wp_query_args_latest_posts->have_posts() ) :
  	$wp_query_args_latest_posts->the_post();

    //Start Get Images Posts
    $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-medium-tow' );
    $image = '<figure class="post-image">';
    $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
    $image .= '</figure>';

    //Start Get Category Posts
  	$categories = get_the_category( get_the_ID() );
  	$catname = $categories[0]->name;
  	$class = strtolower($catname);
  	$class = str_replace(' ', '-', $class);
  	$class = sanitize_title($class);

  	$categories_category = "";
  	$categories_category = get_the_category( get_the_ID() );
  	$categories_firstCategory = $categories_category[0]->cat_ID;

  	$post_categories = '
  	<div class="post-category category-bg-color">
  		<ul>
  			<li>
  				<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
  			</li>
  		</ul>
  	</div>
  	';

		//Start Get Meta Posts
	  $views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();

		if ( ot_get_option('post_view_count') == 'on' )  {
			$post_view_count = '<li class="post-views"><span><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</span></li>';
		} else {
			$post_view_count = '';
		}

    $post_information = '
    '.$post_view_count.'
    <li class="post-data"><span><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span></li>
    <li class="post-comment"><span><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</span></li>
  	';

		//Start Post Rating
		$id = get_the_ID();
		if ($atts['postreview']=='on') :
			if(! get_post_meta($id, 'review_score', true)) :
				$rating_number = "";
			else:
				$ratings_count = get_post_meta($id, 'review_score', true);
				$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
			endif;
		else:
			$rating_number = "";
		endif;

    //Start Loop Posts
  	$output .= '
    <li>
    <div class="featured-posts">
      <article class="post post-overlay">
        <div class="featured-slider">
          '. $image . '
					'.$rating_number.'
          <div class="post-detail">
            '.$post_categories.'
            <div class="post-title">
              <h2><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h2>
            </div>
						<div class="post-content entry-content">
							<p>'.cairo_string_limit_words(get_the_excerpt(), 20).'</p>
						</div>
      			<div class="meta-slider-content">
      				<ul>
      					'.$post_information.'
      				</ul>
            </div>
          </div>
        </div>
      </article>
    </div>
    </li>
    ';
    ; endwhile;
  	wp_reset_postdata();

  	$output .= '</ul>';
  	$output .= '</div>';
  	$output .= '</div>';
  	return $output;

	// ==========================================================================================
  // Featurd Slider Style 8
  // ==========================================================================================

	elseif (strstr( $atts['style'], "style8" )) :

    $output .= '<div class="featured-post-slider featured-style8">';
  	$output .= '<div class="featured-block">';
  	$output .= '<ul class="featured-slider-posts featured-style-8 codepages-loading">';

		//Start Query Featurd Posts
		$featured_one = array(
		  'post__in'							=> $bypostid,
		  'author'								=> $atts['authorids'],
		  'posts_per_page' 				=> $postcount,
		  'post_status'						=> 'publish',
		  'orderby'  				    	=> 'date',
		  'cat' 									=> $atts['cat'],
		  'post__not_in' 					=> $excludepost,
		  'category__not_in' 			=> $excludecategoy,
		  'tag__not_in'						=> $excludetags,
		  'ignore_sticky_posts' 	=> true,
		  'post_type' 						=> 'post'
		);

		if ( $atts['source'] == 'by-tag') {
			$featured_one = wp_parse_args(
				array(
					'tag__in' 	=> explode(',', $atts['posttag']),
				)
			, $featured_one );
		}

		//Start Query
  	$wp_query_args_latest_posts = new WP_Query( $featured_one );
  	while ( $wp_query_args_latest_posts->have_posts() ) :
  	$wp_query_args_latest_posts->the_post();

    //Start Get Images Posts
    $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-small-five' );
    $image = '<figure class="post-image">';
    $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
    $image .= '</figure>';

    //Start Get Category Posts
  	$categories = get_the_category( get_the_ID() );
  	$catname = $categories[0]->name;
  	$class = strtolower($catname);
  	$class = str_replace(' ', '-', $class);
  	$class = sanitize_title($class);

  	$categories_category = "";
  	$categories_category = get_the_category( get_the_ID() );
  	$categories_firstCategory = $categories_category[0]->cat_ID;

  	$post_categories = '
  	<div class="post-category category-bg-color">
  		<ul>
  			<li>
  				<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
  			</li>
  		</ul>
  	</div>
  	';

		//Start Get Meta Posts
	  $views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();

		if ( ot_get_option('post_view_count') == 'on' )  {
			$post_view_count = '<li class="post-views"><span><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</span></li>';
		} else {
			$post_view_count = '';
		}

    $post_information = '
    '.$post_view_count.'
    <li class="post-comment"><span><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</span></li>
  	';

		//Start Post Rating
		$id = get_the_ID();
		if ($atts['postreview']=='on') :
			if(! get_post_meta($id, 'review_score', true)) :
				$rating_number = "";
			else:
				$ratings_count = get_post_meta($id, 'review_score', true);
				$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
			endif;
		else:
			$rating_number = "";
		endif;

    //Start Loop Posts
  	$output .= '
    <li>
    <div class="featured-posts">
      <article class="post post-overlay">
        <div class="featured-slider">
          '. $image . '
					'.$rating_number.'
          <div class="post-detail">
            '.$post_categories.'
            <div class="post-title">
              <h4><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h4>
            </div>
      			<div class="meta-slider-content">
      				<ul>
      					'.$post_information.'
      				</ul>
            </div>
          </div>
        </div>
      </article>
    </div>
    </li>
    ';
    ; endwhile;
  	wp_reset_postdata();

  	$output .= '</ul>';
  	$output .= '</div>';
  	$output .= '</div>';
  	return $output;

		// ==========================================================================================
	  // Featurd Slider Style 9
	  // ==========================================================================================

	// ==========================================================================================
  // Featurd Slider Style 9
  // ==========================================================================================

	elseif (strstr( $atts['style'], "style9" )) :

	    $output .= '<div class="featured-post-slider featured-style9">';
	  	$output .= '<div class="featured-block">';
	  	$output .= '<ul class="featured-slider-posts featured-style-9 codepages-loading">';

			//Start Query Featurd Posts
			$featured_one = array(
			  'post__in'							=> $bypostid,
			  'author'								=> $atts['authorids'],
			  'posts_per_page' 				=> $postcount,
			  'post_status'						=> 'publish',
			  'orderby'  				    	=> 'date',
			  'cat' 									=> $atts['cat'],
			  'post__not_in' 					=> $excludepost,
			  'category__not_in' 			=> $excludecategoy,
			  'tag__not_in'						=> $excludetags,
			  'ignore_sticky_posts' 	=> true,
			  'post_type' 						=> 'post'
			);

			if ( $atts['source'] == 'by-tag') {
				$featured_one = wp_parse_args(
					array(
						'tag__in' 	=> explode(',', $atts['posttag']),
					)
				, $featured_one );
			}

			//Start Query
	  	$wp_query_args_latest_posts = new WP_Query( $featured_one );
	  	while ( $wp_query_args_latest_posts->have_posts() ) :
	  	$wp_query_args_latest_posts->the_post();

	    //Start Get Images Posts
	    $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-medium-six' );
	    $image = '<figure class="post-image">';
	    $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
	    $image .= '</figure>';

	    //Start Get Category Posts
	  	$categories = get_the_category( get_the_ID() );
	  	$catname = $categories[0]->name;
	  	$class = strtolower($catname);
	  	$class = str_replace(' ', '-', $class);
	  	$class = sanitize_title($class);

	  	$categories_category = "";
	  	$categories_category = get_the_category( get_the_ID() );
	  	$categories_firstCategory = $categories_category[0]->cat_ID;

	  	$post_categories = '
	  	<div class="post-category category-bg-color">
	  		<ul>
	  			<li>
	  				<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
	  			</li>
	  		</ul>
	  	</div>
	  	';

			//Start Get Meta Posts
		  $views = cairo_get_post_views(get_the_ID());
			$num_comments = get_comments_number();

			if ( ot_get_option('post_view_count') == 'on' )  {
				$post_view_count = '<li class="post-views"><span><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</span></li>';
			} else {
				$post_view_count = '';
			}

	    $post_information = '
	    '.$post_view_count.'
	    <li class="post-data"><span><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span></li>
	    <li class="post-comment"><span><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</span></li>
	  	';

			//Start Post Rating
			$id = get_the_ID();
			if ($atts['postreview']=='on') :
				if(! get_post_meta($id, 'review_score', true)) :
					$rating_number = "";
				else:
					$ratings_count = get_post_meta($id, 'review_score', true);
					$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
				endif;
			else:
				$rating_number = "";
			endif;

	    //Start Loop Posts
	  	$output .= '
	    <li>
	    <div class="featured-posts">
	      <article class="post post-overlay">
	        <div class="featured-slider">
	          '. $image . '
						'.$rating_number.'
	          <div class="post-detail">
	            '.$post_categories.'
	            <div class="post-title">
	              <h2><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h2>
	            </div>
	      			<div class="meta-slider-content">
	      				<ul>
	      					'.$post_information.'
	      				</ul>
	            </div>
	          </div>
	        </div>
	      </article>
	    </div>
	    </li>
	    ';
	    ; endwhile;
	  	wp_reset_postdata();

	  	$output .= '</ul>';
	  	$output .= '</div>';
	  	$output .= '</div>';
	  	return $output;

		// ==========================================================================================
	  // Featurd Slider Style Ten
	  // ==========================================================================================

	// ==========================================================================================
  // Featurd Slider Style 10
  // ==========================================================================================

	elseif (strstr( $atts['style'], "styleten" )) :

    $output .= '<div class="featured-post-slider featured-styleten">';
  	$output .= '<div class="featured-block">';
  	$output .= '<ul class="featured-slider-posts featured-style-10 codepages-loading">';

		//Start Query Featurd Posts
		$featured_one = array(
		  'post__in'							=> $bypostid,
		  'author'								=> $atts['authorids'],
		  'posts_per_page' 				=> $postcount,
		  'post_status'						=> 'publish',
		  'orderby'  				    	=> 'date',
		  'cat' 									=> $atts['cat'],
		  'post__not_in' 					=> $excludepost,
		  'category__not_in' 			=> $excludecategoy,
		  'tag__not_in'						=> $excludetags,
		  'ignore_sticky_posts' 	=> true,
		  'post_type' 						=> 'post'
		);

		if ( $atts['source'] == 'by-tag') {
			$featured_one = wp_parse_args(
				array(
					'tag__in' 	=> explode(',', $atts['posttag']),
				)
			, $featured_one );
		}

		//Start Query
  	$wp_query_args_latest_posts = new WP_Query( $featured_one );
  	while ( $wp_query_args_latest_posts->have_posts() ) :
  	$wp_query_args_latest_posts->the_post();

    //Start Get Images Posts
    $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-small-five' );
    $image = '<figure class="post-image">';
    $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
    $image .= '</figure>';

    //Start Get Category Posts
  	$categories = get_the_category( get_the_ID() );
  	$catname = $categories[0]->name;
  	$class = strtolower($catname);
  	$class = str_replace(' ', '-', $class);
  	$class = sanitize_title($class);

  	$categories_category = "";
  	$categories_category = get_the_category( get_the_ID() );
  	$categories_firstCategory = $categories_category[0]->cat_ID;

  	$post_categories = '
  	<div class="post-category category-bg-color">
  		<ul>
  			<li>
  				<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
  			</li>
  		</ul>
  	</div>
  	';

		//Start Get Meta Posts
	  $views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();

		if ( ot_get_option('post_view_count') == 'on' )  {
			$post_view_count = '<li class="post-views"><span><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</span></li>';
		} else {
			$post_view_count = '';
		}

    $post_information = '
    '.$post_view_count.'
    <li class="post-data"><span><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span></li>
    <li class="post-comment"><span><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</span></li>
  	';

		//Start Post Rating
		$id = get_the_ID();
		if ($atts['postreview']=='on') :
			if(! get_post_meta($id, 'review_score', true)) :
				$rating_number = "";
			else:
				$ratings_count = get_post_meta($id, 'review_score', true);
				$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
			endif;
		else:
			$rating_number = "";
		endif;

    //Start Loop Posts
  	$output .= '
    <li>
    <div class="featured-posts">
      <article class="post post-overlay">
        <div class="featured-slider">
          '. $image . '
					'.$rating_number.'
          <div class="post-detail">
            '.$post_categories.'
            <div class="post-title">
              <h3><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h3>
            </div>
      			<div class="meta-slider-content">
      				<ul>
      					'.$post_information.'
      				</ul>
            </div>
          </div>
        </div>
      </article>
    </div>
    </li>
    ';
    ; endwhile;
  	wp_reset_postdata();

  	$output .= '</ul>';
  	$output .= '</div>';
  	$output .= '</div>';
  	return $output;

	// ==========================================================================================
  // Featurd Slider Style 11
  // ==========================================================================================

	elseif (strstr( $atts['style'], "styleeleven" )) :

    $output .= '<div class="featured-post-slider featured-style11">';
  	$output .= '<div class="featured-block">';
  	$output .= '<ul class="featured-slider-posts featured-style-11 codepages-loading">';

		//Start Query Featurd Posts
		$featured_one = array(
		  'post__in'							=> $bypostid,
		  'author'								=> $atts['authorids'],
		  'posts_per_page' 				=> $postcount,
		  'post_status'						=> 'publish',
		  'orderby'  				    	=> 'date',
		  'cat' 									=> $atts['cat'],
		  'post__not_in' 					=> $excludepost,
		  'category__not_in' 			=> $excludecategoy,
		  'tag__not_in'						=> $excludetags,
		  'ignore_sticky_posts' 	=> true,
		  'post_type' 						=> 'post'
		);

		if ( $atts['source'] == 'by-tag') {
			$featured_one = wp_parse_args(
				array(
					'tag__in' 	=> explode(',', $atts['posttag']),
				)
			, $featured_one );
		}

		//Start Query
  	$wp_query_args_latest_posts = new WP_Query( $featured_one );
  	while ( $wp_query_args_latest_posts->have_posts() ) :
  	$wp_query_args_latest_posts->the_post();

    //Start Get Images Posts
    $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-large-one' );
    $image = '<figure class="post-image">';
    $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
    $image .= '</figure>';

    //Start Get Category Posts
  	$categories = get_the_category( get_the_ID() );
  	$catname = $categories[0]->name;
  	$class = strtolower($catname);
  	$class = str_replace(' ', '-', $class);
  	$class = sanitize_title($class);

  	$categories_category = "";
  	$categories_category = get_the_category( get_the_ID() );
  	$categories_firstCategory = $categories_category[0]->cat_ID;

  	$post_categories = '
  	<div class="post-category category-bg-color">
  		<ul>
  			<li>
  				<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
  			</li>
  		</ul>
  	</div>
  	';

		//Start Get Meta Posts
	  $views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();

		if ( ot_get_option('post_view_count') == 'on' )  {
			$post_view_count = '<li class="post-views"><span><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</span></li>';
		} else {
			$post_view_count = '';
		}

    $post_information = '
    '.$post_view_count.'
    <li class="post-data"><span><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span></li>
    <li class="post-comment"><span><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</span></li>
  	';

		//Start Post Rating
		$id = get_the_ID();
		if ($atts['postreview']=='on') :
			if(! get_post_meta($id, 'review_score', true)) :
				$rating_number = "";
			else:
				$ratings_count = get_post_meta($id, 'review_score', true);
				$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
			endif;
		else:
			$rating_number = "";
		endif;

    //Start Loop Posts
  	$output .= '
    <li>
    <div class="featured-posts">
      <article class="post post-overlay">
        <div class="featured-slider">
          '. $image . '
					'.$rating_number.'
          <div class="post-detail">
            '.$post_categories.'
            <div class="post-title">
              <h2><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h2>
            </div>
      			<div class="meta-slider-content">
      				<ul>
      					'.$post_information.'
      				</ul>
            </div>
						<div class="Read-More text-center">
							<a href="' . get_the_permalink() . '" class="button post-more">
								<span>' .  esc_html__('Continue Reading', 'cairo') . '</span>
								<span><i class="fa fa-long-arrow-right"></i></span>
							</a>
						</div>
          </div>
        </div>
      </article>
    </div>
    </li>
    ';
    ; endwhile;
  	wp_reset_postdata();

  	$output .= '</ul>';
  	$output .= '</div>';
  	$output .= '</div>';
  	return $output;

	// ==========================================================================================
  // Featurd Slider Style 12
  // ==========================================================================================

	elseif (strstr( $atts['style'], "styletwelve" )) :

	  $output .= '<div class="featured-post-slider featured-style12">';
		$output .= '<div class="featured-block">';

		//Start Query Featurd Posts
		$featured_one = array(
		  'post__in'							=> $bypostid,
		  'author'								=> $atts['authorids'],
		  'posts_per_page' 				=> $postcount,
		  'post_status'						=> 'publish',
		  'orderby'  				    	=> 'date',
		  'cat' 									=> $atts['cat'],
		  'post__not_in' 					=> $excludepost,
		  'category__not_in' 			=> $excludecategoy,
		  'tag__not_in'						=> $excludetags,
		  'ignore_sticky_posts' 	=> true,
		  'post_type' 						=> 'post'
		);

		if ( $atts['source'] == 'by-tag') {
			$featured_one = wp_parse_args(
				array(
					'tag__in' 	=> explode(',', $atts['posttag']),
				)
			, $featured_one );
		}

		$output .= '<ul class="featured-slider-posts featured-style-12 codepages-loading">';

		//Start Query
		$wp_query_args_latest_posts = new WP_Query( $featured_one );
		while ( $wp_query_args_latest_posts->have_posts() ) :
		$wp_query_args_latest_posts->the_post();

	  //Start Get Images Posts
	  $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-large-one' );
	  $image = '<figure class="post-image">';
	  $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
	  $image .= '</figure>';

	  //Start Get Category Posts
		$categories = get_the_category( get_the_ID() );
		$catname = $categories[0]->name;
		$class = strtolower($catname);
		$class = str_replace(' ', '-', $class);
		$class = sanitize_title($class);

		$categories_category = "";
		$categories_category = get_the_category( get_the_ID() );
		$categories_firstCategory = $categories_category[0]->cat_ID;

		$post_categories = '
		<div class="post-category category-bg-color">
			<ul>
				<li>
					<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
				</li>
			</ul>
		</div>
		';

		//Start Get Meta Posts
	  $views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();

		if ( ot_get_option('post_view_count') == 'on' )  {
			$post_view_count = '<li class="post-views"><span><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</span></li>';
		} else {
			$post_view_count = '';
		}

	  $post_information = '
	  '.$post_view_count.'
	  <li class="post-data"><span><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span></li>
	  <li class="post-comment"><span><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</span></li>
		';

		//Start Post Rating
		$id = get_the_ID();
		if ($atts['postreview']=='on') :
			if(! get_post_meta($id, 'review_score', true)) :
				$rating_number = "";
			else:
				$ratings_count = get_post_meta($id, 'review_score', true);
				$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
			endif;
		else:
			$rating_number = "";
		endif;

	  //Start Loop Posts
		$output .= '
	  <li>
	  <div class="featured-posts post-style7">
	    <article class="post post-overlay">
	      <div class="featured-slider">
	        '. $image . '
					'.$rating_number.'
	        <div class="post-detail">
		        <div class="entry-header">
		          '.$post_categories.'
		          <div class="post-title">
		            <h2><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h2>
		          </div>
		    			<div class="meta-slider-content">
		    				<ul>
		    					'.$post_information.'
		    				</ul>
		          </div>
		        </div>
	        </div>
	      </div>
	    </article>
	  </div>
	  </li>
	  ';
	  ; endwhile;
		wp_reset_postdata();

		$output .= '</ul>';

		$output .= '<ul class="featured-slider-posts featured-style-nav-12 codepages-loading">';

		//Start Query
		$wp_query_args_latest_posts = new WP_Query( $featured_one );
		while ( $wp_query_args_latest_posts->have_posts() ) :
		$wp_query_args_latest_posts->the_post();

		//Start Get Images Posts
		$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-thumb-tow' );
		$image = '<figure class="post-image">';
		$image .= '<img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" />';
		$image .= '</figure>';

		//Start Loop Posts
		$output .= '
		<li>
		<div class="featured-posts">
			<article class="post post-overlay">
				<div class="featured-slider">
					'. $image . '
				</div>
			</article>
		</div>
		</li>
		';
		; endwhile;
		wp_reset_postdata();

		$output .= '</ul>';

		$output .= '</div>';
		$output .= '</div>';
		return $output;

	// ==========================================================================================
  // Featurd Slider Style 13
  // ==========================================================================================

	elseif (strstr( $atts['style'], "stylethirty" )) :

	  $output .= '<div class="featured-post-slider featured-style13">';
		$output .= '<div class="featured-block">';

		//Start Query Featurd Posts
		$featured_one = array(
		  'post__in'							=> $bypostid,
		  'author'								=> $atts['authorids'],
		  'posts_per_page' 				=> $postcount,
		  'post_status'						=> 'publish',
		  'orderby'  				    	=> 'date',
		  'cat' 									=> $atts['cat'],
		  'post__not_in' 					=> $excludepost,
		  'category__not_in' 			=> $excludecategoy,
		  'tag__not_in'						=> $excludetags,
		  'ignore_sticky_posts' 	=> true,
		  'post_type' 						=> 'post'
		);

		if ( $atts['source'] == 'by-tag') {
			$featured_one = wp_parse_args(
				array(
					'tag__in' 	=> explode(',', $atts['posttag']),
				)
			, $featured_one );
		}

		$output .= '<ul class="featured-slider-posts featured-style-13 codepages-loading">';

		//Start Query
		$wp_query_args_latest_posts = new WP_Query( $featured_one );
		while ( $wp_query_args_latest_posts->have_posts() ) :
		$wp_query_args_latest_posts->the_post();

	  //Start Get Images Posts
	  $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-large-tow' );
	  $image = '<figure class="post-image">';
	  $image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
	  $image .= '</figure>';

	  //Start Get Category Posts
		$categories = get_the_category( get_the_ID() );
		$catname = $categories[0]->name;
		$class = strtolower($catname);
		$class = str_replace(' ', '-', $class);
		$class = sanitize_title($class);

		$categories_category = "";
		$categories_category = get_the_category( get_the_ID() );
		$categories_firstCategory = $categories_category[0]->cat_ID;

		$post_categories = '
		<div class="post-category category-bg-color">
			<ul>
				<li>
					<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
				</li>
			</ul>
		</div>
		';

		//Start Get Meta Posts
	  $views = cairo_get_post_views(get_the_ID());
		$num_comments = get_comments_number();

		if ( ot_get_option('post_view_count') == 'on' )  {
			$post_view_count = '<li class="post-views"><span><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</span></li>';
		} else {
			$post_view_count = '';
		}

	  $post_information = '
	  '.$post_view_count.'
	  <li class="post-data"><span><i class="fa fa-clock-o"></i><a href="'.get_the_permalink().'">' . get_the_time( get_option( 'date_format' ) ) . '</a></span></li>
	  <li class="post-comment"><span><i class="fa fa-commenting-o"></i>'.$num_comments.' ' .  esc_html__('Comments', 'cairo') . '</span></li>
		';

		//Start Post Rating
		$id = get_the_ID();
		if ($atts['postreview']=='on') :
			if(! get_post_meta($id, 'review_score', true)) :
				$rating_number = "";
			else:
				$ratings_count = get_post_meta($id, 'review_score', true);
				$rating_number = '<div class="review-rating-post"><span class="review-rating-score">'.$ratings_count.'</span></div>';
			endif;
		else:
			$rating_number = "";
		endif;

	  //Start Loop Posts
		$output .= '
	  <li>
	  <div class="featured-posts post-style7">
	    <article class="post post-overlay">
	      <div class="featured-slider">
	        '. $image . '
					'.$rating_number.'
	        <div class="post-detail">
		        <div class="entry-header">
		          '.$post_categories.'
		          <div class="post-title">
		            <h2><a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a></h2>
		          </div>
		    			<div class="meta-slider-content">
		    				<ul>
		    					'.$post_information.'
		    				</ul>
		          </div>
		        </div>
	        </div>
	      </div>
	    </article>
	  </div>
	  </li>
	  ';
	  ; endwhile;
		wp_reset_postdata();

		$output .= '</ul>';

		$output .= '<ul class="featured-slider-posts featured-style-nav-13 codepages-loading">';

		//Start Query
		$wp_query_args_latest_posts = new WP_Query( $featured_one );
		while ( $wp_query_args_latest_posts->have_posts() ) :
		$wp_query_args_latest_posts->the_post();

		//Start Get Category Posts
		$categories = get_the_category( get_the_ID() );
		$catname = $categories[0]->name;
		$class = strtolower($catname);
		$class = str_replace(' ', '-', $class);
		$class = sanitize_title($class);

		$categories_category = "";
		$categories_category = get_the_category( get_the_ID() );
		$categories_firstCategory = $categories_category[0]->cat_ID;

		$post_categories = '
		<div class="post-category category-text-color">
			<ul>
				<li>
					<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
				</li>
			</ul>
		</div>
		';

		//Start Loop Posts
		$output .= '
		<li>
		<div class="featured-posts">
			<article class="post post-overlay">
				<div class="post-detail">
					<div class="entry-header">
						'.$post_categories.'
						<div class="post-title">
							<h5>'. get_the_title() .'</h5>
						</div>
					</div>
				</div>
			</article>
		</div>
		</li>
		';
		; endwhile;
		wp_reset_postdata();
		$output .= '</ul>';

		$output .= '</div>';
		$output .= '</div>';
		return $output;
	endif;
}
add_shortcode("codepages_featurd_sliders", "codepages_featurd_slider");
