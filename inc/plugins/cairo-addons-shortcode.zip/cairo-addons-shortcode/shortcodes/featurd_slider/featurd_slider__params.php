<?php

$post_categories = get_terms("category");
$post_categories_array = array();
$post_categories_array[__("All Categories", 'cairo')] = "-";
foreach($post_categories as $post_category) {
  $post_categories_array[$post_category->name] =  $post_category->term_id;
}

// ==========================================================================================
// Featured Posts Style
// ==========================================================================================

vc_map( array(
  "name" 			=> esc_html__("Featured Posts", 'cairo'),
  "base" 			=> "codepages_featurd_sliders",
  "class" 		=> "",
  "category" 		=> esc_html__("Cairo Theme", 'cairo'),
  "icon"      	=> "ti ti-layout-slider",
  "description" 	=>esc_html__( 'Featured posts widget.','cairo'),
  "params"		=> array(
    //Featured Style
    array(
      "type" => "dropdown",
      "class" => "",
      "heading" => esc_html__("Style",'cairo'),
      "description" => esc_html__("Select the design element.",'cairo'),
      "param_name" => "style",
      "admin_label" => true,
      "value" => array(
        esc_html__("None Select", 'cairo') => "none",
        esc_html__("Style 1", 'cairo') => "style1",
        esc_html__("Style 2", 'cairo') => "style2",
        esc_html__("Style 3", 'cairo') => "style3",
        esc_html__("Style 4", 'cairo') => "style4",
        esc_html__("Style 5", 'cairo') => "style5",
        esc_html__("Style 6", 'cairo') => "style6",
        esc_html__("Style 7", 'cairo') => "style7",
        esc_html__("Style 8", 'cairo') => "style8",
        esc_html__("Style 9", 'cairo') => "style9",
        esc_html__("Style 10", 'cairo') => "styleten",
        esc_html__("Style 11", 'cairo') => "styleeleven",
        esc_html__("Style 12", 'cairo') => "styletwelve",
        esc_html__("Style 13", 'cairo') => "stylethirty",
      )
    ),
    //Style 1
    array(
      'type'	=> 'imagethup',
      'heading'	=> '',
      'param_name'	=> 'styleoneimage',
      'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-1.png',
      'dependency' => Array('element' => "style", 'value' => array('style1'))
    ),
    //Style 2
    array(
      'type'	=> 'imagethup',
      'heading'	=> '',
      'param_name'	=> 'styletwoimage',
      'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-2.png',
      'dependency' => Array('element' => "style", 'value' => array('style2'))
    ),
    //Style 3
    array(
      'type'	=> 'imagethup',
      'heading'	=> '',
      'param_name'	=> 'stylethereeimage',
      'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-3.png',
      'dependency' => Array('element' => "style", 'value' => array('style3'))
    ),
    //Style 4
    array(
      'type'	=> 'imagethup',
      'heading'	=> '',
      'param_name'	=> 'stylefourimage',
      'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-4.png',
      'dependency' => Array('element' => "style", 'value' => array('style4'))
    ),
    //Style 5
    array(
      'type'	=> 'imagethup',
      'heading'	=> '',
      'param_name'	=> 'stylefiveimage',
      'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-5.png',
      'dependency' => Array('element' => "style", 'value' => array('style5'))
    ),
    //Style 6
    array(
      'type'	=> 'imagethup',
      'heading'	=> '',
      'param_name'	=> 'stylesiximage',
      'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-6.png',
      'dependency' => Array('element' => "style", 'value' => array('style6'))
    ),
    //Style 7
    array(
      'type'	=> 'imagethup',
      'heading'	=> '',
      'param_name'	=> 'stylesevenimage',
      'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-7.png',
      'dependency' => Array('element' => "style", 'value' => array('style7'))
    ),
    //Style 8
    array(
      'type'	=> 'imagethup',
      'heading'	=> '',
      'param_name'	=> 'styleeightimage',
      'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-8.png',
      'dependency' => Array('element' => "style", 'value' => array('style8'))
    ),
    //Style 9
    array(
      'type'	=> 'imagethup',
      'heading'	=> '',
      'param_name'	=> 'stylesnineimage',
      'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-9.png',
      'dependency' => Array('element' => "style", 'value' => array('style9'))
    ),
    //Style 10
    array(
      'type'	=> 'imagethup',
      'heading'	=> '',
      'param_name'	=> 'styletenimage',
      'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-10.png',
      'dependency' => Array('element' => "style", 'value' => array('styleten'))
    ),
    //Style 11
    array(
      'type'	=> 'imagethup',
      'heading'	=> '',
      'param_name'	=> 'styleelevenimage',
      'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-11.png',
      'dependency' => Array('element' => "style", 'value' => array('styleeleven'))
    ),
    //Style 12
    array(
      'type'	=> 'imagethup',
      'heading'	=> '',
      'param_name'	=> 'styletwelveimage',
      'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-11.png',
      'dependency' => Array('element' => "style", 'value' => array('styletwelve'))
    ),
    //Style 13
    array(
      'type'	=> 'imagethup',
      'heading'	=> '',
      'param_name'	=> 'stylethirtyimage',
      'value' => get_template_directory_uri().'/assets/images/admin/slider-posts/cairo-featured-style-11.png',
      'dependency' => Array('element' => "style", 'value' => array('stylethirty'))
    ),

    //Post Rating
    array(
      "type" => "dropdown",
      "class" => "",
      "heading" => esc_html__("Show Post Review",'cairo'),
      "description" => esc_html__("You can on/off Post Review",'cairo'),
      "param_name" => "postreview",
      "value" => array(
        esc_html__("On", 'cairo') => 'on',
        esc_html__("Off", 'cairo') => 'off',
      ),
      'std'   => 'off',
    ),

    //Post Count
    array(
      "type"			=>	"textfield",
      "class"			=>	"",
      "heading"		=>	esc_html__('Post Count', 'cairo'),
      "description"	=>  esc_html__('Enter Post Count', 'cairo'),
      "param_name"	=>	"postcount",
      "value"			=>	"",
      "admin_label" => true,
    ),

    //Exclude Post
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Exclude Posts",'cairo'),
      "description" => esc_html__("Enter exclude posts(s) id. Separate with commas 1,2,3 etc.",'cairo'),
      'group' => esc_html__("Exclude Settings", 'cairo'),
      "param_name" => "excludeposts",
      "value" => "",
    ),
    //Exclude Category
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Exclude Category",'cairo'),
      "description" => esc_html__("Enter exclude category id. Separate with commas 1,2,3 etc.",'cairo'),
      'group' => esc_html__("Exclude Settings", 'cairo'),
      "param_name" => "excludecategory",
      "value" => "",
    ),
    //Exclude Tag
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Exclude Tags",'cairo'),
      "description" => esc_html__("Enter the tag ID you would like to display seperated by comma",'cairo'),
      'group' => esc_html__("Exclude Settings", 'cairo'),
      "param_name" => "excludetag",
      "value" => "",
    ),

    //Posts Source
    array(
      "type" => "dropdown",
      "heading" => esc_html__("Post Source",'cairo'),
      'group' => esc_html__("Post Source", 'cairo'),
      "param_name" => "source",
      "value" => array(
        'None Select' => 'none',
        'By Category' => 'by-category',
        'By Post ID' => 'by-id',
        'By Tag' => 'by-tag',
        'By Author' => 'by-author',
      ),
      "std" => "most-recent",
      "admin_label" => true,
      "description" => "Select the source of the posts you'd like to show."
    ),

    //Post ID
    array(
      "type"			=>	"textfield",
      "class"			=>	"",
      "heading"		=>	esc_html__('Post ID', 'cairo'),
      "description"	=>	esc_html__('Enter Post ID', 'cairo'),
      'group' => esc_html__("Post Source", 'cairo'),
      "param_name"	=>	"postid",
      "value"			=>	"",
      "dependency" => Array('element' => "source", 'value' => array('by-id'))
    ),

    //Post Tag
    array(
      "type"			=>	"textfield",
      "class"			=>	"",
      "heading"			=>	esc_html__('Tag ID', 'cairo'),
      "description"	=>	esc_html__('Enter the tag ID you would like to display seperated by comma', 'cairo'),
      'group' => esc_html__("Post Source", 'cairo'),
      "param_name"	=>	"posttag",
      "value"			=>	"",
      "dependency" => Array('element' => "source", 'value' => array('by-tag'))
    ),

    //By Category Select
    array(
      "type" => "dropdown",
      "heading" => esc_html__("Post Categories", 'cairo'),
      "description" => esc_html__("Which categories would you like to show?", 'cairo'),
      'group' => esc_html__("Post Source", 'cairo'),
      "param_name" => "cat",
      "value" => $post_categories_array,
      "dependency" => Array('element' => "source", 'value' => array('by-category'))
    ),

    //Authot ID Select
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Author ID's",'cairo'),
      "description" => esc_html__("Enter include author ids.",'cairo'),
      'group' => esc_html__("Post Source", 'cairo'),
      "param_name" => "authorids",
      "value" => "",
      "dependency" => Array('element' => "source", 'value' => array('by-author'))
    ),

    //Post Order By
    array(
      "type" => "dropdown",
      "class" => "",
      "heading" => esc_html__("Post Order By",'cairo'),
      'group' => esc_html__("Post Source", 'cairo'),
      "description" => esc_html__("Post Order By",'cairo'),
      "param_name" => "featuredorderby",
      "value" => array(
        esc_html__("None Select", 'cairo') => "none",
        esc_html__("Date", 'cairo') => 'date',
        esc_html__("Random", 'cairo') => 'rand',
        esc_html__("Comment Count", 'cairo') => 'comment_count',
        )
    ),

  )

));
