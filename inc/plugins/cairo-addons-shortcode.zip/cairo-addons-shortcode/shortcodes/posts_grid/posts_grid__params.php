<?php

$post_categories = get_terms("category");
$post_categories_array = array();
$post_categories_array[__("All Categories", 'cairo')] = "-";
foreach($post_categories as $post_category) {
  $post_categories_array[$post_category->name] =  $post_category->term_id;
}


// ==========================================================================================
// Layout Posts Style
// ==========================================================================================

	vc_map( array(
		"name" 			=> esc_html__("Posts Grid", 'cairo'),
		"base" 			=> "cairo_post_module",
		"class" 		=> "",
		"category" 		=> esc_html__("Cairo Theme", 'cairo'),
		"icon"      	=> "ti ti-layout-grid2",
		"description" 	=>esc_html__( 'Bulid Your Layout Posts Blog.','cairo'),
		"params"		=> array(
			array(
				"type" => "dropdown",
				"heading" => "Style",
				"param_name" => "style",
				"admin_label" => true,
				"value" => array(
					esc_html__("None Select", 'cairo') => "none",
					esc_html__("style 1", 'cairo') => "style1",
					esc_html__("style 2", 'cairo') => "style2",
					esc_html__("style 3", 'cairo') => "style3",
					esc_html__("style 4", 'cairo') => "style4",
					esc_html__("style 5", 'cairo') => "style5",
					esc_html__("style 6", 'cairo') => "style6",
					esc_html__("style 7", 'cairo') => "style7",
				),
				"description" => "This changes the layouts of the grids"
			),
			//Style 1
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'styleoneimage',
				'value' => get_template_directory_uri().'/assets/images/admin/blog_style/cairo_post_style_1.png',
				'dependency' => Array('element' => "style", 'value' => array('style1'))
			),
			//Style 2
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'styletwoimage',
				'value' => get_template_directory_uri().'/assets/images/admin/blog_style/cairo_post_style_2.png',
				'dependency' => Array('element' => "style", 'value' => array('style2'))
			),
			//Style 3
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylethereeimage',
				'value' => get_template_directory_uri().'/assets/images/admin/blog_style/cairo_post_style_3.png',
				'dependency' => Array('element' => "style", 'value' => array('style3'))
			),
			//Style 4
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylefourimage',
				'value' => get_template_directory_uri().'/assets/images/admin/blog_style/cairo_post_style_4.png',
				'dependency' => Array('element' => "style", 'value' => array('style4'))
			),
			//Style 5
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylefiveimage',
				'value' => get_template_directory_uri().'/assets/images/admin/blog_style/cairo_post_style_5.png',
				'dependency' => Array('element' => "style", 'value' => array('style5'))
			),
			//Style 6
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylesiximage',
				'value' => get_template_directory_uri().'/assets/images/admin/blog_style/cairo_post_style_6.png',
				'dependency' => Array('element' => "style", 'value' => array('style6'))
			),
			//Style 7
			array(
				'type'	=> 'imagethup',
				'heading'	=> '',
				'param_name'	=> 'stylesevenimage',
				'value' => get_template_directory_uri().'/assets/images/admin/blog_style/cairo_post_style_7.png',
				'dependency' => Array('element' => "style", 'value' => array('style7'))
			),
			array(
			"type" => "dropdown",
			"heading" => esc_html__("Post Title Style", 'cairo'),
			'group' => esc_html__("Title Settings", 'cairo'),
			"param_name" => "titlestyle",
			"value" => array(
				esc_html__("None Select", 'cairo') => "none",
				'Style1' => "style1",
				'Style2' => "style2",
				'Style3' => "style3",
				'Style4' => "style4",
				'Style5' => "style5",
				'Style6' => "style6",
				'Style7' => "style7",
			),
			"description" => "This changes the layouts of the grids",
			),
			//Column Style Layout
			array(
				'type'	=> 'dropdown',
				'heading'	=> 'Column Style',
				'param_name'	=> 'columnsection',
				'value' => array(
						esc_html__("None Select", 'cairo') => "none-select",
						esc_html__("Tow Column", 'cairo') => "style1",
						esc_html__("Theree Column", 'cairo') => "style2",
				),
				'dependency' => Array('element' => "style", 'value' => array('style2'))
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Posts Title",'cairo'),
				'group' => esc_html__("Title Settings", 'cairo'),
				"description" => esc_html__("Posts Title",'cairo'),
				"param_name" => "posttitle",
				"value" => "",
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => "Number of posts",
				"param_name" => "pppage",
				"value" => "",
				"description" => "The number of posts to show."
			),
			array(
				"type" => "dropdown",
				"heading" => esc_html__("Post Source", 'cairo'),
				"param_name" => "source",
				'group' 		=> esc_html__("Post Filter", 'cairo'),
				"value" => array(
					'None Select' => 'none',
					'By Category' => 'by-category',
					'By Post ID' => 'by-id',
					'By Tag' => 'by-tag',
					'By Author' => 'by-author',
				),
				"admin_label" => true,
				"description" => "Select the source of the posts you'd like to show."
			),
			array(
				"type" => "dropdown",
				"heading" => "Post Categories",
				'group' 		=> esc_html__("Post Filter", 'cairo'),
				"param_name" => "cat",
				"value" => $post_categories_array,
				"description" => "Which categories would you like to show?",
				"dependency" => Array('element' => "source", 'value' => array('by-category'))
			),
			array(
				"type" => "textfield",
				"heading" => "Post IDs",
				'group' 		=> esc_html__("Post Filter", 'cairo'),
				"param_name" => "post_ids",
				"description" => "Enter the post IDs you would like to display seperated by comma",
				"dependency" => Array('element' => "source", 'value' => array('by-id'))
			),
			array(
				"type" => "textfield",
				"heading" => "Tag slugs",
				'group' 		=> esc_html__("Post Filter", 'cairo'),
				"param_name" => "tag_slugs",
				"description" => "Enter the tag ID you would like to display seperated by comma",
				"dependency" => Array('element' => "source", 'value' => array('by-tag'))
			),
			array(
				"type" => "textfield",
				"heading" => "Author IDs",
				'group' 		=> esc_html__("Post Filter", 'cairo'),
				"param_name" => "author_ids",
				"description" => "Enter the Author IDs you would like to display seperated by comma",
				"dependency" => Array('element' => "source", 'value' => array('by-author'))
			),
			//Pos Order By
			array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Post Order By",'cairo'),
			"description" => esc_html__("Post Order By",'cairo'),
			'group' 		=> esc_html__("Post Filter", 'cairo'),
			"param_name" => "categoryorderby",
				"value" => array(
					esc_html__("None Select", 'cairo') => "none",
					esc_html__("Date", 'cairo') => 'date',
					esc_html__("Random", 'cairo') => 'rand',
					esc_html__("Comment Count", 'cairo') => 'comment_count',
				)
			),
			array(
			"type" => "dropdown",
			"heading" => "Pagination Style",
			"param_name" => "pagination",
			"value" => array(
				esc_html__("None Select", 'cairo') => "none",
				'Regular Pagination With Ajax' => "style1",
				'Ajax Load More' => "style2",
				'Next Page and Prev Page' => "style3",
				'Regular Pagination Not Ajax' => "style4",
			),
			"description" => "This changes the layouts of the grids",
			),
		),
	)
);
