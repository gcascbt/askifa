<?php
/**
 *
 * Posts Grid Style
 * @since 1.0.0
 * @version 1.0.0
 *
 */

function cairo_posts_grid( $atts, $content = null ) {

	$atts = shortcode_atts(
		array(
			'style'						=> '',
			'author_ids'			=> '',
			'tag_slugs'				=> '',
			'postid'			  	=> '',
			'most-recent'			=> '',
			'columnsection'		=> '',
			'pagination'			=> '',
			'authorids'				=> '',
			'cat'							=> '',
			'source'					=> '',
			'posttitle'				=> '',
			'titlestyle'			=> '',
			'pppage'					=> '',
			'categoryorderby'	=> '',
		), $atts
	);


	$output = '';

	$paged = is_front_page() ? get_query_var( 'page', 1 ) : get_query_var( 'paged', 1 );

  /*   Start Count Posts     */
	if( !empty( $atts['pppage'] ) ) :
		$postcount = $atts['pppage'];
	else:
		$postcount = "";
	endif;
  /*   End Count Posts     */

  /*   Start Exclude Categoy     */
	if( !empty( $atts['categoryorderby'] ) ) :
  	$categoriesorderby = $atts['categoryorderby'];
  else:
  	$categoriesorderby = "";
  endif;
  /*   End Exclude Categoy     */

  /*   Start Exclude Tag       */
	if( !empty( $atts['tag_slugs'] ) ) :
		$tagsslug = $atts['tag_slugs'];
		$tagsslug = explode( ',', $tagsslug );
	else:
		$tagsslug = "";
	endif;
  /*   End Exclude Tag       */

  /*   Start ID Posts        */
	if( !empty( $atts['postid'] ) ) :
		$bypostid = $atts['postid'];
		$bypostid = explode( ',', $bypostid );
	else:
		$bypostid = "";
	endif;
  /*   End ID Posts         */


	//Query Post
	$post_grid_module = array(
		'post__in'						 => $bypostid,
		'posts_per_page' 			 => $postcount,
		'tag'						       => $tagsslug,
		'post_status'					 => 'publish',
		'author'					     => $atts['author_ids'],
		'orderby'  				     => $categoriesorderby,
		'cat' 								 => $atts['cat'],
		'ignore_sticky_posts'  => true,
		'post_type' 			     => 'post',
		'paged' 					     => $paged
	);


  // ==========================================================================================
  // Grid Posts Style 1
  // ==========================================================================================

	if( strstr( $atts['style'], "style1" ) ) :

		$posts = query_posts( $post_grid_module );

		$output .= '<section class="postgrid-module style1">';

		/*   Start Post Grid Title     */
		$posttitlestyle = $atts['titlestyle'];

		$postareatitle = $atts['posttitle'];
		if( !empty($postareatitle) ) :
		$output .= '<div class="module-title '.$posttitlestyle.'"><h4>'.$postareatitle.'</h4></div>';
		else:
		endif;
		/*   End Post Grid Title     */


		if ( have_posts() ) {
			$output .= '<div id="more-posts-wrapper" class="blog-posts more-posts-wrapper"> ';

			if ($atts['pagination'] == 'style1' || $atts['pagination'] == 'style2') {
				$output .= '<div class="cairo-ajax-pagination">';
			}

			$output .= '<div class="cairo-ajax-content">';
			$output .= '<div class="loading-posts"></div>';

			global $paged;
			if ( get_query_var('paged') ) { $paged = get_query_var('paged'); }
			elseif ( get_query_var('page') ) { $paged = get_query_var('page'); }
			else { $paged = 1; }

			$output .= '<div class="cairo-ajax-wrapper">';

			while ( have_posts() ) : the_post();

			/*   Start Get Images Posts     */
			if ( has_post_thumbnail( get_the_ID() ) ) :
				$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-large-five' );
				$image = '<figure class="post-image">';
				$image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
				$image .= '</figure>';
			else:
				$image = "";
			endif;
			/*   End Get Images Posts     */

	    /*   Start Get Category Posts     */
			$categories = get_the_category( get_the_ID() );
			$catname = $categories[0]->name;
			$class = strtolower($catname);
			$class = str_replace(' ', '-', $class);
			$class = sanitize_title($class);

			$categories_category = "";
			$categories_category = get_the_category( get_the_ID() );
			$categories_firstCategory = $categories_category[0]->cat_ID;

			$post_categories = '
			<div class="post-category category-bg-color">
				<ul>
					<li>
						<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
					</li>
				</ul>
			</div>
			';
	    /*   End Get Category Posts     */


	    /*   Start Get Meta Posts     */
	    $views = cairo_get_post_views(get_the_ID());
			$num_comments = get_comments_number();

			if ( $num_comments == 0 ) : $comments = esc_html__( '0 Comment', 'cairo' );
			elseif ( $num_comments > 1 ) : $comments = $num_comments . esc_html__( ' Comments', 'cairo' );
			else: $comments = esc_html__( '1 Comment', 'cairo' ); endif;

	    $views = cairo_get_post_views(get_the_ID());

			if ( ot_get_option('post_view_count') == 'on' )  {
				$post_view_count = '<li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>';
			} else {
				$post_view_count = '';
			}

	    $post_information = '
			<li class="post-comment"><i class="fa fa-commenting-o"></i>'. $comments .'</li>
			<li class="post-data"><i class="fa fa-clock-o"></i>'.get_the_time( get_option('date_format') ).'</li>
			'.$post_view_count.'
			';

	    /*   End Get Meta Posts     */

	    /*   Start Loop Posts     */
			$output .= '
			<article class="post post-item status-publish post-style1">
				'. $image . '
				<div class="post-content">
					<div class="post-details">
						<div class="post-cat">
							'.$post_categories.'
						</div><!-- post-cat -->
					</div><!-- post-inwrap -->
					<div class="post-title">
						<h2 class="entry-title">
							<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a>
						</h2>
					</div><!-- post-title -->
					<div class="post-excerpt">
						<p>'.cairo_string_limit_words(get_the_excerpt(), 50).'</p>
					</div> <!-- post-entry -->
					<div class="post-meta-box">
						<aside class="post-author">
						'.get_avatar( get_the_author_meta( 'ID' ), 30 ).'
						<a href="'.get_author_posts_url( get_the_author_meta( 'ID' ) ).'">'.get_the_author().'</a>
						</aside>
						<ul class="post-meta no-sep">
							'.$post_information.'
						</ul>
					</div><!-- post-meta -->
				</div><!-- post-content -->
	    </article>
	    ';

	    ; endwhile;
			wp_reset_postdata();
	    /*   End Loop Posts     */


			// Pagination With Ajax Number And Next & Prev.
			if ($atts['pagination'] == 'style1') {
			$output .= '<div class="pagination">';
			$output .= get_the_posts_pagination(
			 array(
			 	'screen_reader_text' => esc_html__('', 'cairo'),
			  'prev_text' => esc_html__( '«', 'cairo' ),
			  'next_text' => esc_html__( '»', 'cairo' ),
				)
			);
			$output .= '</div>';
			}

			// Pagination With Ajax Load More.
			if ($atts['pagination'] == 'style2') {
				$output .= '<div class="ajax-load-more pagination-load-more">';
				$output .= get_next_posts_link('Load More',100);
				$output .='</div>';
			}

			// Pagination Without Ajax Next & Prev.
			if ($atts['pagination'] == 'style3') {
			$output .= '<div class="next-prev-pagination">';
			$output .= '<div class="prev-page">'.get_previous_posts_link().'</div>';
			$output .= '<div class="next-page">'.get_next_posts_link().'</div>';
			$output .= '</div>';
			}

			if ($atts['pagination'] == 'style1' || $atts['pagination'] == 'style2') {
				$output .= '</div>';
			}
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';


			// Pagination Without Ajax Number And Next & Prev.
			if ($atts['pagination'] == 'style4') {
			$output .= '<div class="pagination">';
			$output .= get_the_posts_pagination(
			 array(
			 	'screen_reader_text' => esc_html__('', 'cairo'),
		    'prev_text' => esc_html__( '«', 'cairo' ),
		    'next_text' => esc_html__( '»', 'cairo' ),
				)
			);
			$output .= '</div>';
			}
		}

		$output .= '</section>';

		wp_reset_query();
		return $output;



  // ==========================================================================================
  // Grid Posts Style 2
  // ==========================================================================================

	elseif( strstr( $atts['style'], "style2" ) ) :

		$output .= '<section class="postgrid-module style2">';

		/*   Start Post Grid Title     */
		$posttitlestyle = $atts['titlestyle'];

		$postareatitle = $atts['posttitle'];
		if( !empty($postareatitle) ) :
		$output .= '<div class="module-title '.$posttitlestyle.'"><h4>'.$postareatitle.'</h4></div>';
		else:
		endif;
		/*   End Post Grid Title     */

		$posts = query_posts( $post_grid_module );

		if ( have_posts() ) {
			$output .= '<div id="more-posts-wrapper" class="blog-posts more-posts-wrapper"> ';
			$output .= '<div class="row">';

			if ($atts['pagination'] == 'style1' || $atts['pagination'] == 'style2') {
				$output .= '<div class="cairo-ajax-pagination">';
			}

			$output .= '<div class="cairo-ajax-content">';
			$output .= '<div class="loading-posts"></div>';

			global $paged;
			if ( get_query_var('paged') ) { $paged = get_query_var('paged'); }
			elseif ( get_query_var('page') ) { $paged = get_query_var('page'); }
			else { $paged = 1; }

			$output .= '<div class="cairo-ajax-wrapper">';

			while ( have_posts() ) : the_post();

			/*   Start Get Images Posts     */
			if ( has_post_thumbnail( get_the_ID() ) ) :
				$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-small-tow' );
				$image = '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
			else:
				$image = "";
			endif;
			/*   End Get Images Posts     */

	    /*   Start Get Category Posts     */
			$categories = get_the_category( get_the_ID() );
			$catname = $categories[0]->name;
			$class = strtolower($catname);
			$class = str_replace(' ', '-', $class);
			$class = sanitize_title($class);

			$categories_category = "";
			$categories_category = get_the_category( get_the_ID() );
			$categories_firstCategory = $categories_category[0]->cat_ID;

			$post_categories = '
			<div class="post-category category-bg-color">
				<ul>
					<li>
						<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
					</li>
				</ul>
			</div>
			';
	    /*   End Get Category Posts     */


	    /*   Start Get Meta Posts     */
	    $views = cairo_get_post_views(get_the_ID());
			$num_comments = get_comments_number();

			if ( $num_comments == 0 ) : $comments = esc_html__( '0 Comment', 'cairo' );
			elseif ( $num_comments > 1 ) : $comments = $num_comments . esc_html__( ' Comments', 'cairo' );
			else: $comments = esc_html__( '1 Comment', 'cairo' ); endif;

	    $views = cairo_get_post_views(get_the_ID());

			if ( ot_get_option('post_view_count') == 'on' )  {
				$post_view_count = '<li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>';
			} else {
				$post_view_count = '';
			}

	    $post_information = '
			<li class="post-comment"><i class="fa fa-commenting-o"></i>'. $comments .'</li>
			<li class="post-data"><i class="fa fa-clock-o"></i>'.get_the_time( get_option('date_format') ).'</li>
			'.$post_view_count.'
			';

	    /*   End Get Meta Posts     */

			if ($atts['columnsection']=='style1') {
			$output .= '<div class="col-md-6 col-sm-12 col-xs-12">';
			}
			else{
			$output .= '<div class="col-md-4 col-sm-6 col-xs-12">';
			}

	    /*   Start Loop Posts     */
			$output .= '
			<article class="post status-publish post-style2">
				<figure class="post-image">
					'. $image . '
					<div class="post-cat">
						'.$post_categories.'
					</div><!-- post-cat -->
				</figure>
				<div class="post-content">
					<div class="post-title">
						<h3 class="entry-title">
							<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a>
						</h3>
					</div><!-- post-title -->

					<div class="post-meta-box">
						<ul class="post-meta no-sep">
							'.$post_information.'
						</ul>
					</div><!-- post-meta -->
					<div class="post-excerpt">
						<p>'.cairo_string_limit_words(get_the_excerpt(), 20).'</p>
					</div> <!-- post-entry -->
				</div><!-- post-content -->
	    </article>
	    ';
			$output .= '</div>';

	    ; endwhile;
			wp_reset_postdata();
	    /*   End Loop Posts     */

			$output .= '</div>';

			// Pagination With Ajax Number And Next & Prev.
			if ($atts['pagination'] == 'style1') {
			$output .= '<div class="pagination">';
			$output .= '<ul>';
			$output .= get_the_posts_pagination(
			 array(
			 	'screen_reader_text' => esc_html__('', 'cairo'),
			  'prev_text' => esc_html__( '«', 'cairo' ),
			  'next_text' => esc_html__( '»', 'cairo' ),
				)
			);
			$output .= '</ul>';
			$output .= '</div>';
			}

			// Pagination With Ajax Load More.
			if ($atts['pagination'] == 'style2') {
				$output .= '<div class="ajax-load-more pagination-load-more">';
				$output .= get_next_posts_link('Load More',100);
				$output .='</div>';
			}

			// Pagination Without Ajax Next & Prev.
			if ($atts['pagination'] == 'style3') {
			$output .= '<div class="next-prev-pagination">';
			$output .= '<div class="prev-page">'.get_previous_posts_link().'</div>';
			$output .= '<div class="next-page">'.get_next_posts_link().'</div>';
			$output .= '</div>';
			}

			// Pagination Without Ajax Number And Next & Prev.
			if ($atts['pagination'] == 'style4') {
			$output .= '<div class="pagination">';
			$output .= get_the_posts_pagination(
			 array(
			 	'screen_reader_text' => esc_html__('', 'cairo'),
			    'prev_text' => esc_html__( '«', 'cairo' ),
			    'next_text' => esc_html__( '»', 'cairo' ),
				)
			);
			$output .= '</div>';
			}

			if ($atts['pagination'] == 'style1' || $atts['pagination'] == 'style2') {
				$output .= '</div>';
			}
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';

		}

		$output .= '</section>';

		wp_reset_query();
		return $output;

  // ==========================================================================================
  // Grid Posts Style 3
  // ==========================================================================================

	elseif( strstr( $atts['style'], "style3" ) ) :

		$output .= '<section class="postgrid-module style3">';

		/*   Start Post Grid Title     */
		$posttitlestyle = $atts['titlestyle'];

		$postareatitle = $atts['posttitle'];
		if( !empty($postareatitle) ) :
		$output .= '<div class="module-title '.$posttitlestyle.'"><h4>'.$postareatitle.'</h4></div>';
		else:
		endif;
		/*   End Post Grid Title     */

		$posts = query_posts( $post_grid_module );

		if ( have_posts() ) {
			$output .= '<div id="more-posts-wrapper" class="blog-posts more-posts-wrapper"> ';
			$output .= '<div class="row">';

			if ($atts['pagination'] == 'style1' || $atts['pagination'] == 'style2') {
				$output .= '<div class="cairo-ajax-pagination">';
			}

			$output .= '<div class="cairo-ajax-content">';
			$output .= '<div class="loading-posts"></div>';

			global $paged;
			if ( get_query_var('paged') ) { $paged = get_query_var('paged'); }
			elseif ( get_query_var('page') ) { $paged = get_query_var('page'); }
			else { $paged = 1; }

			$output .= '<div class="cairo-ajax-wrapper">';

			while ( have_posts() ) : the_post();

			/*   Start Get Images Posts     */
			if ( has_post_thumbnail( get_the_ID() ) ) :
				$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-small-tow' );
				$image = '<figure class="post-image">';
				$image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
				$image .= '</figure>';
			else:
				$image = "";
			endif;
			/*   End Get Images Posts     */

	    /*   Start Get Category Posts     */
			$categories = get_the_category( get_the_ID() );
			$catname = $categories[0]->name;
			$class = strtolower($catname);
			$class = str_replace(' ', '-', $class);
			$class = sanitize_title($class);

			$categories_category = "";
			$categories_category = get_the_category( get_the_ID() );
			$categories_firstCategory = $categories_category[0]->cat_ID;

			$post_categories = '
			<div class="post-category category-bg-color">
				<ul>
					<li>
						<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
					</li>
				</ul>
			</div>
			';
	    /*   End Get Category Posts     */


	    /*   Start Get Meta Posts     */
	    $views = cairo_get_post_views(get_the_ID());
			$num_comments = get_comments_number();

			if ( $num_comments == 0 ) : $comments = esc_html__( '0 Comment', 'cairo' );
			elseif ( $num_comments > 1 ) : $comments = $num_comments . esc_html__( ' Comments', 'cairo' );
			else: $comments = esc_html__( '1 Comment', 'cairo' ); endif;

	    $views = cairo_get_post_views(get_the_ID());

			if ( ot_get_option('post_view_count') == 'on' )  {
				$post_view_count = '<li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>';
			} else {
				$post_view_count = '';
			}

	    $post_information = '
			<li class="post-comment"><i class="fa fa-commenting-o"></i>'. $comments .'</li>
			'.$post_view_count.'
			';

	    /*   End Get Meta Posts     */

	    /*   Start Loop Posts     */
			$output .= '
			<article class="post post-item status-publish post-style3">
				<div class="col-sm-5 col-xs-12">
				'.$image.'
				</div>
				<div class="col-sm-7 col-xs-12">
					<div class="post-detail">
						<div class="post-meta top-meta">
							<div class="post-cat">
								'.$post_categories.'
							</div><!-- post-cat -->
							<div class="post-data">
								'.get_the_time( get_option('date_format') ).'
							</div>
						</div><!-- post-meta -->

						<div class="post-title">
							<h3 class="entry-title">
								<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a>
							</h3>
						</div><!-- post-title -->

						<div class="post-excerpt">
							<p>'.cairo_string_limit_words(get_the_excerpt(), 18).'</p>
						</div> <!-- post-excerpt -->

						<div class="post-meta bottom-meta">
							<aside class="post-author">
							'.get_avatar( get_the_author_meta( 'ID' ), 30 ).'
							<a href="'.get_author_posts_url( get_the_author_meta( 'ID' ) ).'">'.get_the_author().'</a>
							</aside>
							<ul class="post-meta-info">
								'.$post_information.'
							</ul>
						</div><!-- post-meta -->
					</div><!-- post-detail -->
				</div>
	    </article>
	    ';

	    ; endwhile;
			wp_reset_postdata();
	    /*   End Loop Posts     */

			$output .= '</div>';

			// Pagination With Ajax Number And Next & Prev.
			if ($atts['pagination'] == 'style1') {
			$output .= '<div class="pagination">';
			$output .= '<ul>';
			$output .= get_the_posts_pagination(
			 array(
			 	'screen_reader_text' => esc_html__('', 'cairo'),
			  'prev_text' => esc_html__( '«', 'cairo' ),
			  'next_text' => esc_html__( '»', 'cairo' ),
				)
			);
			$output .= '</ul>';
			$output .= '</div>';
			}

			// Pagination With Ajax Load More.
			if ($atts['pagination'] == 'style2') {
				$output .= '<div class="ajax-load-more pagination-load-more">';
				$output .= get_next_posts_link('Load More',100);
				$output .='</div>';
			}

			// Pagination Without Ajax Next & Prev.
			if ($atts['pagination'] == 'style3') {
			$output .= '<div class="next-prev-pagination">';
			$output .= '<div class="prev-page">'.get_previous_posts_link().'</div>';
			$output .= '<div class="next-page">'.get_next_posts_link().'</div>';
			$output .= '</div>';
			}

			if ($atts['pagination'] == 'style1' || $atts['pagination'] == 'style2') {
				$output .= '</div>';
			}
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';

			// Pagination Without Ajax Number And Next & Prev.
			if ($atts['pagination'] == 'style4') {
			$output .= '<div class="pagination">';
			$output .= get_the_posts_pagination(
			 array(
			 	'screen_reader_text' => esc_html__('', 'cairo'),
			    'prev_text' => esc_html__( '«', 'cairo' ),
			    'next_text' => esc_html__( '»', 'cairo' ),
				)
			);
			$output .= '</div>';
			}
		}

		$output .= '</section>';

		wp_reset_query();
		return $output;

  // ==========================================================================================
  // Grid Posts Style 4
  // ==========================================================================================

	elseif (strstr( $atts['style'], "style4" )) :

		$output .= '<section class="postgrid-module style4">';

		/*   Start Post Grid Title     */
		$posttitlestyle = $atts['titlestyle'];

		$postareatitle = $atts['posttitle'];
		if( !empty($postareatitle) ) :
		$output .= '<div class="module-title '.$posttitlestyle.'"><h4>'.$postareatitle.'</h4></div>';
		else:
		endif;
		/*   End Post Grid Title     */

		$posts = query_posts( $post_grid_module );

		if ( have_posts() ) {
			$output .= '<div id="more-posts-wrapper" class="blog-posts more-posts-wrapper"> ';
			$output .= '<div class="row">';

			if ($atts['pagination'] == 'style1' || $atts['pagination'] == 'style2') {
				$output .= '<div class="cairo-ajax-pagination">';
			}

			$output .= '<div class="cairo-ajax-content">';
			$output .= '<div class="loading-posts"></div>';

			global $paged;
			if ( get_query_var('paged') ) { $paged = get_query_var('paged'); }
			elseif ( get_query_var('page') ) { $paged = get_query_var('page'); }
			else { $paged = 1; }

			$output .= '<div class="cairo-ajax-wrapper">';

			while ( have_posts() ) : the_post();

			/*   Start Get Images Posts     */
			if ( has_post_thumbnail( get_the_ID() ) ) :
				$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-medium-four' );
				$image = '<figure class="post-image">';
				$image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
				$image .= '</figure>';
			else:
				$image = "";
			endif;
			/*   End Get Images Posts     */

	    /*   Start Get Category Posts     */
			$categories = get_the_category( get_the_ID() );
			$catname = $categories[0]->name;
			$class = strtolower($catname);
			$class = str_replace(' ', '-', $class);
			$class = sanitize_title($class);

			$categories_category = "";
			$categories_category = get_the_category( get_the_ID() );
			$categories_firstCategory = $categories_category[0]->cat_ID;

			$post_categories = '
			<div class="post-category category-bg-color">
				<ul>
					<li>
						<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
					</li>
				</ul>
			</div>
			';
	    /*   End Get Category Posts     */


	    /*   Start Get Meta Posts     */
	    $views = cairo_get_post_views(get_the_ID());
			$num_comments = get_comments_number();

			if ( $num_comments == 0 ) : $comments = esc_html__( '0 Comment', 'cairo' );
			elseif ( $num_comments > 1 ) : $comments = $num_comments . esc_html__( ' Comments', 'cairo' );
			else: $comments = esc_html__( '1 Comment', 'cairo' ); endif;

	    $views = cairo_get_post_views(get_the_ID());

			if ( ot_get_option('post_view_count') == 'on' )  {
				$post_view_count = '<li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>';
			} else {
				$post_view_count = '';
			}

	    $post_information = '
			<li class="post-comment"><i class="fa fa-commenting-o"></i>'. $comments .'</li>
			'.$post_view_count.'
			';

	    /*   End Get Meta Posts     */

	    /*   Start Loop Posts     */
			$output .= '
			<article class="post post-item status-publish post-style4">
				<div class="col-sm-7 col-sm-12 col-xs-12">
					'.$image .'
				</div>
				<div class="col-sm-5 col-sm-12 col-xs-12">
					<div class="post-detail">
						<div class="post-meta top-meta">
							<div class="post-cat">
								'.$post_categories.'
							</div><!-- post-cat -->
							<div class="post-data">
								'.get_the_time( get_option('date_format') ).'
							</div>
						</div><!-- post-meta -->

						<div class="post-title">
							<h3 class="entry-title">
								<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a>
							</h3>
						</div><!-- post-title -->

						<div class="post-excerpt">
							<p>'.cairo_string_limit_words(get_the_excerpt(), 18).'</p>
						</div> <!-- post-excerpt -->

						<div class="post-meta bottom-meta">
							<aside class="post-author">
								'.get_avatar( get_the_author_meta( 'ID' ), 30 ).'
						 		<a href="'.get_author_posts_url( get_the_author_meta( 'ID' ) ).'">'.get_the_author().'</a>
							</aside>
							<ul class="post-meta-info">
								'.$post_information.'
							</ul>
						</div><!-- post-meta -->
					</div><!-- post-detail -->
				</div>
			</article>
	    ';

	    ; endwhile;
			wp_reset_postdata();
	    /*   End Loop Posts     */

			$output .= '</div>';

			// Pagination With Ajax Number And Next & Prev.
			if ($atts['pagination'] == 'style1') {
			$output .= '<div class="pagination">';
			$output .= '<ul>';
			$output .= get_the_posts_pagination(
			 array(
			 	'screen_reader_text' => esc_html__('', 'cairo'),
			  'prev_text' => esc_html__( '«', 'cairo' ),
			  'next_text' => esc_html__( '»', 'cairo' ),
				)
			);
			$output .= '</ul>';
			$output .= '</div>';
			}

			// Pagination With Ajax Load More.
			if ($atts['pagination'] == 'style2') {
				$output .= '<div class="ajax-load-more pagination-load-more">';
				$output .= get_next_posts_link('Load More',100);
				$output .='</div>';
			}

			// Pagination Without Ajax Next & Prev.
			if ($atts['pagination'] == 'style3') {
			$output .= '<div class="next-prev-pagination">';
			$output .= '<div class="prev-page">'.get_previous_posts_link().'</div>';
			$output .= '<div class="next-page">'.get_next_posts_link().'</div>';
			$output .= '</div>';
			}

			if ($atts['pagination'] == 'style1' || $atts['pagination'] == 'style2') {
				$output .= '</div>';
			}
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';


			// Pagination Without Ajax Number And Next & Prev.
			if ($atts['pagination'] == 'style4') {
			$output .= '<div class="pagination">';
			$output .= get_the_posts_pagination(
			 array(
			 	'screen_reader_text' => esc_html__('', 'cairo'),
			    'prev_text' => esc_html__( '«', 'cairo' ),
			    'next_text' => esc_html__( '»', 'cairo' ),
				)
			);
			$output .= '</div>';
			}
		}

		$output .= '</section>';

		wp_reset_query();
		return $output;



  // ==========================================================================================
  // Grid Posts Style 5
  // ==========================================================================================

	elseif (strstr( $atts['style'], "style5" )) :

		$output .= '<section class="postgrid-module style4">';

		/*   Start Post Grid Title     */
		$posttitlestyle = $atts['titlestyle'];

		$postareatitle = $atts['posttitle'];
		if( !empty($postareatitle) ) :
		$output .= '<div class="module-title '.$posttitlestyle.'"><h4>'.$postareatitle.'</h4></div>';
		else:
		endif;
		/*   End Post Grid Title     */

		$posts = query_posts( $post_grid_module );

		if ( have_posts() ) {
			$output .= '<div id="more-posts-wrapper" class="blog-posts more-posts-wrapper"> ';
			$output .= '<div class="row">';

			if ($atts['pagination'] == 'style1' || $atts['pagination'] == 'style2') {
				$output .= '<div class="cairo-ajax-pagination">';
			}

			$output .= '<div class="cairo-ajax-content">';
			$output .= '<div class="loading-posts"></div>';

			global $paged;
			if ( get_query_var('paged') ) { $paged = get_query_var('paged'); }
			elseif ( get_query_var('page') ) { $paged = get_query_var('page'); }
			else { $paged = 1; }

			$output .= '<div class="cairo-ajax-wrapper">';

			while ( have_posts() ) : the_post();

			/*   Start Get Images Posts     */
			if ( has_post_thumbnail( get_the_ID() ) ) :
				$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-small-tow' );
				$image = '<figure class="post-image">';
				$image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
				$image .= '</figure>';
			else:
				$image = "";
			endif;
			/*   End Get Images Posts     */

	    /*   Start Get Category Posts     */
			$categories = get_the_category( get_the_ID() );
			$catname = $categories[0]->name;
			$class = strtolower($catname);
			$class = str_replace(' ', '-', $class);
			$class = sanitize_title($class);

			$categories_category = "";
			$categories_category = get_the_category( get_the_ID() );
			$categories_firstCategory = $categories_category[0]->cat_ID;

			$post_categories = '
			<div class="post-category category-bg-color">
				<ul>
					<li>
						<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
					</li>
				</ul>
			</div>
			';
	    /*   End Get Category Posts     */


	    /*   Start Get Meta Posts     */
	    $views = cairo_get_post_views(get_the_ID());
			$num_comments = get_comments_number();

			if ( $num_comments == 0 ) : $comments = esc_html__( '0 Comment', 'cairo' );
			elseif ( $num_comments > 1 ) : $comments = $num_comments . esc_html__( ' Comments', 'cairo' );
			else: $comments = esc_html__( '1 Comment', 'cairo' ); endif;

	    $views = cairo_get_post_views(get_the_ID());

			if ( ot_get_option('post_view_count') == 'on' )  {
				$post_view_count = '<li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>';
			} else {
				$post_view_count = '';
			}

	    $post_information = '
			<li class="post-comment"><i class="fa fa-commenting-o"></i>'. $comments .'</li>
			'.$post_view_count.'
			';

	    /*   End Get Meta Posts     */

	    /*   Start Loop Posts     */
			$output .= '
			<article class="post post-item status-publish post-style5">
				<div class="col-md-6 col-sm-12 col-xs-12">
					'.$image.'
				</div>
				<div class="col-md-6 col-sm-12 col-xs-12">
					<div class="post-detail">
						<div class="post-meta top-meta">
							<div class="post-cat">
								'.$post_categories.'
							</div><!-- post-cat -->
							<div class="post-data">
								'.get_the_time( get_option('date_format') ).'
							</div>
						</div><!-- post-meta -->

						<div class="post-title">
							<h3 class="entry-title">
								<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a>
							</h3>
						</div><!-- post-title -->

						<div class="post-excerpt">
							<p>'.cairo_string_limit_words(get_the_excerpt(), 18).'</p>
						</div> <!-- post-excerpt -->

						<div class="post-meta bottom-meta">
							<aside class="post-author">
							'.get_avatar( get_the_author_meta( 'ID' ), 30 ).'
							'.get_the_author().'
							</aside>
							<ul class="post-meta-info">
								'.$post_information.'
							</ul>
						</div><!-- post-meta -->
					</div><!-- post-detail -->
				</div>
	    </article>
	    ';

	    ; endwhile;
			wp_reset_postdata();
	    /*   End Loop Posts     */

			$output .= '</div>';

			// Pagination With Ajax Number And Next & Prev.
			if ($atts['pagination'] == 'style1') {
			$output .= '<div class="pagination">';
			$output .= '<ul>';
			$output .= get_the_posts_pagination(
			 array(
			 	'screen_reader_text' => esc_html__('', 'cairo'),
			  'prev_text' => esc_html__( '«', 'cairo' ),
			  'next_text' => esc_html__( '»', 'cairo' ),
				)
			);
			$output .= '</ul>';
			$output .= '</div>';
			}

			// Pagination With Ajax Load More.
			if ($atts['pagination'] == 'style2') {
				$output .= '<div class="ajax-load-more pagination-load-more">';
				$output .= get_next_posts_link('Load More',100);
				$output .='</div>';
			}

			// Pagination Without Ajax Next & Prev.
			if ($atts['pagination'] == 'style3') {
			$output .= '<div class="next-prev-pagination">';
			$output .= '<div class="prev-page">'.get_previous_posts_link().'</div>';
			$output .= '<div class="next-page">'.get_next_posts_link().'</div>';
			$output .= '</div>';
			}

			if ($atts['pagination'] == 'style1' || $atts['pagination'] == 'style2') {
				$output .= '</div>';
			}
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';


			// Pagination Without Ajax Number And Next & Prev.
			if ($atts['pagination'] == 'style4') {
			$output .= '<div class="pagination">';
			$output .= get_the_posts_pagination(
			 array(
			 	'screen_reader_text' => esc_html__('', 'cairo'),
			    'prev_text' => esc_html__( '«', 'cairo' ),
			    'next_text' => esc_html__( '»', 'cairo' ),
				)
			);
			$output .= '</div>';
			}
		}

		$output .= '</section>';

		wp_reset_query();
		return $output;

  // ==========================================================================================
  // Grid Posts Style 6
  // ==========================================================================================

	elseif (strstr( $atts['style'], "style6" )) :

		$output .= '<section class="postgrid-module style4">';

		/*   Start Post Grid Title     */
		$posttitlestyle = $atts['titlestyle'];

		$postareatitle = $atts['posttitle'];
		if( !empty($postareatitle) ) :
		$output .= '<div class="module-title '.$posttitlestyle.'"><h4>'.$postareatitle.'</h4></div>';
		else:
		endif;
		/*   End Post Grid Title     */

		$posts = query_posts( $post_grid_module );

		if ( have_posts() ) {
			$output .= '<div id="more-posts-wrapper" class="blog-posts more-posts-wrapper"> ';
			$output .= '<div class="row">';

			if ($atts['pagination'] == 'style1' || $atts['pagination'] == 'style2') {
				$output .= '<div class="cairo-ajax-pagination">';
			}

			$output .= '<div class="cairo-ajax-content">';
			$output .= '<div class="loading-posts"></div>';

			global $paged;
			if ( get_query_var('paged') ) { $paged = get_query_var('paged'); }
			elseif ( get_query_var('page') ) { $paged = get_query_var('page'); }
			else { $paged = 1; }

			$output .= '<div class="cairo-ajax-wrapper">';

			while ( have_posts() ) : the_post();

			/*   Start Get Images Posts     */
			if ( has_post_thumbnail( get_the_ID() ) ) :
				$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-medium-tow' );
				$image = '<figure class="post-image">';
				$image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
				$image .= '</figure>';
			else:
				$image = "";
			endif;
			/*   End Get Images Posts     */

	    /*   Start Get Category Posts     */
			$categories = get_the_category( get_the_ID() );
			$catname = $categories[0]->name;
			$class = strtolower($catname);
			$class = str_replace(' ', '-', $class);
			$class = sanitize_title($class);

			$categories_category = "";
			$categories_category = get_the_category( get_the_ID() );
			$categories_firstCategory = $categories_category[0]->cat_ID;

			$post_categories = '
			<div class="post-category category-bg-color">
				<ul>
					<li>
						<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
					</li>
				</ul>
			</div>
			';
	    /*   End Get Category Posts     */


	    /*   Start Get Meta Posts     */
	    $views = cairo_get_post_views(get_the_ID());
			$num_comments = get_comments_number();

			if ( $num_comments == 0 ) : $comments = esc_html__( '0 Comment', 'cairo' );
			elseif ( $num_comments > 1 ) : $comments = $num_comments . esc_html__( ' Comments', 'cairo' );
			else: $comments = esc_html__( '1 Comment', 'cairo' ); endif;

	    $views = cairo_get_post_views(get_the_ID());

			if ( ot_get_option('post_view_count') == 'on' )  {
				$post_view_count = '<li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>';
			} else {
				$post_view_count = '';
			}

	    $post_information = '
			<li class="post-comment"><i class="fa fa-commenting-o"></i>'. $comments .'</li>
			<li class="post-data"><i class="fa fa-clock-o"></i>'.get_the_time( get_option('date_format') ).'</li>
			'.$post_view_count.'
			';

	    /*   End Get Meta Posts     */

	    /*   Start Loop Posts     */
			$output .= '
			<div class="post-item col-sm-6 col-xs-12 hg-item">
				<article class="post status-publish post-style6">
					'.$image.'
					<div class="post-detail">
						<div class="entry-header">
							'.$post_categories.'
							<div class="post-title">
								<h3 class="entry-title">
									<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a>
								</h3>
							</div><!-- post-title -->
							<div class="post-meta-box">
								<ul class="post-meta no-sep">
									'.$post_information.'
								</ul>
							</div><!-- post-meta -->
						</div><!-- entry-header -->
					</div><!-- post-detail -->
				</article><!-- post -->
			</div>
	    ';

	    ; endwhile;
			wp_reset_postdata();
	    /*   End Loop Posts     */

			$output .= '</div>';

			// Pagination With Ajax Number And Next & Prev.
			if ($atts['pagination'] == 'style1') {
			$output .= '<div class="pagination">';
			$output .= '<ul>';
			$output .= get_the_posts_pagination(
			 array(
			 	'screen_reader_text' => esc_html__('', 'cairo'),
			  'prev_text' => esc_html__( '«', 'cairo' ),
			  'next_text' => esc_html__( '»', 'cairo' ),
				)
			);
			$output .= '</ul>';
			$output .= '</div>';
			}

			// Pagination With Ajax Load More.
			if ($atts['pagination'] == 'style2') {
				$output .= '<div class="ajax-load-more pagination-load-more">';
				$output .= get_next_posts_link('Load More',100);
				$output .='</div>';
			}

			// Pagination Without Ajax Next & Prev.
			if ($atts['pagination'] == 'style3') {
			$output .= '<div class="next-prev-pagination">';
			$output .= '<div class="prev-page">'.get_previous_posts_link().'</div>';
			$output .= '<div class="next-page">'.get_next_posts_link().'</div>';
			$output .= '</div>';
			}

			if ($atts['pagination'] == 'style1' || $atts['pagination'] == 'style2') {
				$output .= '</div>';
			}
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';

			// Pagination Without Ajax Number And Next & Prev.
			if ($atts['pagination'] == 'style4') {
			$output .= '<div class="pagination">';
			$output .= get_the_posts_pagination(
			 array(
			 	'screen_reader_text' => esc_html__('', 'cairo'),
			    'prev_text' => esc_html__( '«', 'cairo' ),
			    'next_text' => esc_html__( '»', 'cairo' ),
				)
			);
			$output .= '</div>';
			}


		}

		$output .= '</section>';

		wp_reset_query();
		return $output;

  // ==========================================================================================
  // Grid Posts Style 7
  // ==========================================================================================

	elseif (strstr( $atts['style'], "style7" )) :

		$output .= '<section class="postgrid-module style4">';

		/*   Start Post Grid Title     */
		$posttitlestyle = $atts['titlestyle'];

		$postareatitle = $atts['posttitle'];
		if( !empty($postareatitle) ) :
		$output .= '<div class="module-title '.$posttitlestyle.'"><h4>'.$postareatitle.'</h4></div>';
		else:
		endif;
		/*   End Post Grid Title     */

		$i = 0;
		$posts = query_posts( $post_grid_module );

		if ( have_posts() ) {
			$output .= '<div id="more-posts-wrapper" class="blog-posts more-posts-wrapper"> ';
			$output .= '<div class="row">';

			if ($atts['pagination'] == 'style1' || $atts['pagination'] == 'style2') {
				$output .= '<div class="cairo-ajax-pagination">';
			}

			$output .= '<div class="cairo-ajax-content">';
			$output .= '<div class="loading-posts"></div>';

			global $paged;
			if ( get_query_var('paged') ) { $paged = get_query_var('paged'); }
			elseif ( get_query_var('page') ) { $paged = get_query_var('page'); }
			else { $paged = 1; }

			$output .= '<div class="cairo-ajax-wrapper">';

			while ( have_posts() ) : the_post();

	    /*   Start Get Category Posts     */
			$categories = get_the_category( get_the_ID() );
			$catname = $categories[0]->name;
			$class = strtolower($catname);
			$class = str_replace(' ', '-', $class);
			$class = sanitize_title($class);

			$categories_category = "";
			$categories_category = get_the_category( get_the_ID() );
			$categories_firstCategory = $categories_category[0]->cat_ID;

			$post_categories = '
			<div class="post-category category-bg-color">
				<ul>
					<li>
						<a  class="cat-color-'.$categories_firstCategory.'" href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>
					</li>
				</ul>
			</div>
			';
	    /*   End Get Category Posts     */

	    /*   Start Get Meta Posts     */
	    $views = cairo_get_post_views(get_the_ID());
			$num_comments = get_comments_number();

			if ( $num_comments == 0 ) : $comments = esc_html__( '0 Comment', 'cairo' );
			elseif ( $num_comments > 1 ) : $comments = $num_comments . esc_html__( ' Comments', 'cairo' );
			else: $comments = esc_html__( '1 Comment', 'cairo' ); endif;

	    $views = cairo_get_post_views(get_the_ID());

	    /*   End Get Meta Posts     */

			/*   Start Loop Posts     */
			if ($i == 0) {

				$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-large-five' );
				$image = '<figure class="post-image">';
				$image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
				$image .= '</figure>';

				if ( ot_get_option('post_view_count') == 'on' )  {
					$post_view_count = '<li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>';
				} else {
					$post_view_count = '';
				}

				$post_information = '
				<li class="post-comment"><i class="fa fa-commenting-o"></i>'. $comments .'</li>
				<li class="post-data"><i class="fa fa-clock-o"></i>'.get_the_time( get_option('date_format') ).'</li>
				'.$post_view_count.'
				';


				$output .= '
				<div class="post-item col-md-12 col-sm-12 col-xs-12">
					<article class="post status-publish post-style7">
						'. $image . '
						<div class="post-detail">
							<div class="entry-header">
								'.$post_categories.'
								<div class="post-title">
									<h2 class="entry-title">
										<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a>
									</h2>
								</div><!-- post-title -->
								<div class="post-meta-box">
									<ul class="post-meta no-sep">
										'.$post_information.'
									</ul>
								</div><!-- post-meta -->
							</div><!-- entry-header -->
						</div><!-- post-detail -->
					</article>
				</div>
		    ';

	    } else {

				$image_url = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), $size = 'cairo-post-small-tow' );
				$image = '<figure class="post-image">';
				$image .= '<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '"><img src="' . esc_url( $image_url[0] ) . '" alt="' . the_title_attribute( array( 'echo' => 0) ) . '" /></a>';
				$image .= '</figure>';

				if ( ot_get_option('post_view_count') == 'on' )  {
					$post_view_count = '<li class="post-views"><i class="fa fa-eye"></i>'.$views.' ' .  esc_html__('Views', 'cairo') . '</li>';
				} else {
					$post_view_count = '';
				}

				$post_information = '
				<li class="post-comment"><i class="fa fa-commenting-o"></i>'. $comments .'</li>
				'.$post_view_count.'
				';


				$output .='
				<article class="post post-item status-publish post-style3">
					<div class="col-sm-5 col-xs-12">
						'.$image.'
					</div>
					<div class="col-sm-7 col-xs-12">
						<div class="post-detail">
							<div class="post-meta top-meta">
								<div class="post-cat">
									'.$post_categories.'
								</div><!-- post-cat -->
								<div class="post-data">
									'.get_the_time( get_option('date_format') ).'
								</div>
							</div><!-- post-meta -->

							<div class="post-title">
								<h3 class="entry-title">
									<a href="' . get_the_permalink() . '" title="' . the_title_attribute( array( 'echo' => 0) ) . '">'. get_the_title() .'</a>
								</h3>
							</div><!-- post-title -->

							<div class="post-excerpt">
								<p>'.cairo_string_limit_words(get_the_excerpt(), 18).'</p>
							</div> <!-- post-excerpt -->

							<div class="post-meta bottom-meta">
								<aside class="post-author">
								'.get_avatar( get_the_author_meta( 'ID' ), 30 ).'
								<a href="'.get_author_posts_url( get_the_author_meta( 'ID' ) ).'">'.get_the_author().'</a>
								</aside>
								<ul class="post-meta-info">
									'.$post_information.'
								</ul>
							</div><!-- post-meta -->
						</div><!-- post-detail -->
					</div>
		    </article>
				';
			}

			$i++
	    ; endwhile;
			wp_reset_postdata();
	    /*   End Loop Posts     */

			$output .= '</div>';

			// Pagination With Ajax Number And Next & Prev.
			if ($atts['pagination'] == 'style1') {
			$output .= '<div class="pagination">';
			$output .= '<ul>';
			$output .= get_the_posts_pagination(
			 array(
			 	'screen_reader_text' => esc_html__('', 'cairo'),
			  'prev_text' => esc_html__( '«', 'cairo' ),
			  'next_text' => esc_html__( '»', 'cairo' ),
				)
			);
			$output .= '</ul>';
			$output .= '</div>';
			}

			// Pagination With Ajax Load More.
			if ($atts['pagination'] == 'style2') {
				$output .= '<div class="ajax-load-more pagination-load-more">';
				$output .= get_next_posts_link('Load More',100);
				$output .='</div>';
			}

			// Pagination Without Ajax Next & Prev.
			if ($atts['pagination'] == 'style3') {
			$output .= '<div class="next-prev-pagination">';
			$output .= '<div class="prev-page">'.get_previous_posts_link().'</div>';
			$output .= '<div class="next-page">'.get_next_posts_link().'</div>';
			$output .= '</div>';
			}

			if ($atts['pagination'] == 'style1' || $atts['pagination'] == 'style2') {
				$output .= '</div>';
			}
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';


			// Pagination Without Ajax Number And Next & Prev.
			if ($atts['pagination'] == 'style4') {
			$output .= '<div class="pagination">';
			$output .= get_the_posts_pagination(
			 array(
			 	'screen_reader_text' => esc_html__('', 'cairo'),
			    'prev_text' => esc_html__( '«', 'cairo' ),
			    'next_text' => esc_html__( '»', 'cairo' ),
				)
			);
			$output .= '</div>';
			}
		}

		$output .= '</section>';

		wp_reset_query();
		return $output;

	endif;

}
add_shortcode("cairo_post_module", "cairo_posts_grid");
