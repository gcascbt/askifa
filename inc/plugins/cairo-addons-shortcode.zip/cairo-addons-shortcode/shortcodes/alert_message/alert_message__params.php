<?php
// ==========================================================================================
// Natifaction Moduel Element
// ==========================================================================================

vc_map( array(
  "name" 					=> esc_html__("Natifaction Box ", 'cairo'),
  "base" 					=> "codepages_alert_module",
  "class" 				=> "",
  "category" 			=> esc_html__("Cairo Theme", 'cairo'),
  "icon"      		=> "ti ti-info-alt",
  "description" 	=>esc_html__( 'Bulid Your Layout Posts Blog.','cairo'),
  "params"				=> array(
    array(
      "type" => "dropdown",
      "heading" =>  esc_html__("Natifaction Types",'cairo'),
      "param_name" => "alert_type",
      "admin_label" => true,
      "value" => array(
        esc_html__("None Select", 'cairo') => "none",
        esc_html__("Success", 'cairo') => "success",
        esc_html__("Info", 'cairo') => "info",
        esc_html__("Warning", 'cairo') => "warning",
        esc_html__("Danger", 'cairo') => "danger",
      ),
      "description" => "This changes the style of Natifaction",
    ),
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Natifaction Text", 'cairo'),
      "param_name" => "alert_text",
      "value" => "",
      "description" => esc_html__( "add your text in natifaction.", 'cairo' ),
    ),
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Extra Class", 'cairo'),
      "param_name" => "extra_class",
      "value" => "",
      "description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'cairo' ),
      'group' => esc_html__("Extra Settings", 'cairo'),
    ),
    array(
      "type" => "textfield",
      "class" => "",
      "heading" => esc_html__("Extra ID", 'cairo'),
      "param_name" => "extra_id",
      "value" => "",
      "description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a id name and then refer to it in your css file.", 'cairo' ),
      'group' => esc_html__("Extra Settings", 'cairo'),
    ),
  ),
));
