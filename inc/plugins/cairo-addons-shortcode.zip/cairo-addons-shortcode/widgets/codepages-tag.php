<?php

// ==========================================================================================
// Codepages Tag Widget
// ==========================================================================================

class codepages_tags extends WP_Widget {

	public function __construct() {
			$widget_ops = array(
				'classname'   => 'widget_tags',
				'description' => esc_html_x( 'A short description about you.', 'Tag Cloud widget description', 'codepages' )
			);
			$control_ops = array( 'id_base' => 'widget_tags' );
			parent::__construct( 'widget_tags', sprintf( esc_html_x( ':. %s - Tag Cloud', 'Tag Cloud widget name', 'codepages' ), CAIRO_THEME_NAME ), $widget_ops, $control_ops );
	 }

	public function widget( $args, $instance ) {
		extract( $args );

		$title = apply_filters('widget_title', $instance['title']);

		echo ( $args['before_widget'] );
		if (!empty($title)) {
				echo ( $args['before_title'] . $title . $args['after_title'] );
		}
		$tags = get_tags();
		?>
		<div class="widget-tags">
			<div class="tags">
				<ul>
					<?php
						foreach ( $tags as $tag ):
							$tag_link = get_tag_link( $tag->term_id );
					?>
					<li><a href="<?php echo $tag_link ; ?>"><?php echo $tag->name; ?></a></li>
					<?php endforeach; ?>
				</ul>
			</div><!-- .item-tags -->
		</div>
		<?php
		echo wp_kses_post( $args['after_widget'] );
	}

	public function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		return $instance;
	}

	public function form($instance) {
		$instance = wp_parse_args( (array) $instance, array('title'=>'Tags') );
		$title = strip_tags($instance['title']);
    ?>
  	<p>
      <label for="<?php echo $this->get_field_id('title'); ?>"><?php esc_html_e('Widget title', 'codepages'); ?>:</label>
      <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
    </p>
    <?php
	}
}

function codepages_tags_widget() {
	register_widget( 'codepages_tags' );
}
add_action( 'widgets_init', 'codepages_tags_widget' );
