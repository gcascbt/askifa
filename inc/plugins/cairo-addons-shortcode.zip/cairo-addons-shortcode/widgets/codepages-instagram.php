<?php

// ==========================================================================================
// Codepages Instagram Feed Widget
// ==========================================================================================

class widget_cairo_instagram extends WP_Widget {

  /**
   * @var integer
   */
  private $count;

   public function __construct() {
      $widget_ops = array(
        'classname'   => 'instagram_widget',
        'description' => esc_html_x( 'A short description about you.', 'Instagram widget description', 'cairo' )
      );
      $control_ops = array( 'id_base' => 'instagram_widget' );
      parent::__construct( 'instagram_widget', sprintf( esc_html_x( ':. %s - Instagram', 'Instagram widget name', 'cairo' ), CAIRO_THEME_NAME ), $widget_ops, $control_ops );
   }

   /**
    * Front-end display of widget.
    */
    public function widget($args, $instance) {
        extract($args);
        $title = apply_filters('widget_title', $instance['title']);
        $username  = isset( $instance['username'] ) ? $instance['username'] : '';
        $number = isset( $instance['number'] ) ? $instance['number'] : '6';

        echo ( $args['before_widget'] );
        if (!empty($title)) {
            echo ( $args['before_title'] . $title . $args['after_title'] );
        }
        if ( $username != '' ) {
            $media_array = $this->scrape_instagram( $username, $number );
            if ( is_wp_error( $media_array ) ) {
                echo wp_kses_post( $media_array->get_error_message() );
            } else {
                $media_array = array_filter( $media_array );
                echo '<div class="widget-instagram"><div class="instafeed"><ul class="instagram">';
                foreach ( $media_array as $item ) {
                   echo '<li><a href="'. esc_url( $item['link'] ) .'" target="_blank"><img src="'. esc_url( $item['images']['thumbnail'] ) .'"  alt="'. esc_attr( $item['caption'] ) .'" title="'. esc_attr( $item['caption'] ).'"></a></li>';
                }
                echo '</ul></div></div>';

            }
        }
        echo ( $args['after_widget'] );
    }
    /**
     * Back-end widget form.
     */
    public function form( $instance ) {
        $instance = wp_parse_args( (array) $instance, array(
            'title' => '',
            'username' => '',
            'number'  => 6
            ) );
        ?>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('title') ); ?>"><?php echo 'Title:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('username') ); ?>"><?php echo 'Username:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('username') ); ?>" name="<?php echo esc_attr( $this->get_field_name('username') ); ?>" type="text" value="<?php echo esc_attr( $instance['username'] );  ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('number') ); ?>"><?php echo 'Number of Pictures:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('number') ); ?>" name="<?php echo esc_attr( $this->get_field_name('number') ); ?>" type="text" value="<?php echo esc_attr( $instance['number'] ); ?>">
        </p>

        <?php
    }

    /**
     * Sanitize widget form values as they are saved.
     */
    public function update( $new_instance, $old_instance ) {
        $instance = $old_instance;
        $instance['title'] = strip_tags( $new_instance['title'] );
        $instance['username']    = $new_instance['username'];
        $instance['number'] = $new_instance['number'];
        return $instance;
    }

    // based on https://gist.github.com/cosmocatalano/4544576

    public function scrape_instagram( $username, $token, $method = 'username', $count = 12, $max_id = '' )
    {
	    $response = wp_remote_get( $this->get_url( $username, $token, $method, $max_id ) , array(
		    'timeout' => 10,
	    ));

	    if ( !is_wp_error( $response ) && $response['response']['code'] == '200' )
	    {
		    $data_images = array();

		    if ( $method === 'username')
		    {
			    $data      = explode( 'window._sharedData = ', $response['body'] );
			    $data_json = explode( ';</script>', $data[1] );
			    $data_json = json_decode( $data_json[0], TRUE );

			    foreach ( $data_json['entry_data']['ProfilePage'][0]['graphql']['user']['edge_owner_to_timeline_media']['edges'] as $image )
			    {
				    $data_images[] = array(
					    'id'          => $image['node']['id'],
					    'time'        => $image['node']['taken_at_timestamp'],
					    'like'        => $image['node']['edge_liked_by']['count'],
					    'comment'     => $image['node']['edge_media_to_comment']['count'],
					    'caption'     => !empty( $image['node']['edge_media_to_caption']['edges'][0]['node']['text'] ) ? preg_replace('/[^a-zA-Z0-9\-]/', ' ', $image['node']['edge_media_to_caption']['edges'][0]['node']['text']) : '',
					    'link'        => trailingslashit( '//instagram.com/p/' . $image['node']['shortcode'] ),
					    'images'      => array(
						    'display'   => $image['node']['display_url'],
						    'thumbnail' => $image['node']['thumbnail_src']
					    ),
				    );

				    if ( count($data_images) >= $count )
				    {
					    break;
				    }
			    }

		    } else {
			    $data_json = json_decode( $response['body'], TRUE );

			    foreach ( $data_json['data'] as $image )
			    {
				    $data_images[] = array(
					    'id'          => $image['id'],
					    'time'        => $image['created_time'],
					    'like'        => $image['likes']['count'],
					    'comment'     => $image['comments']['count'],
					    'caption'     => !empty( $image['caption']['text'] ) ? preg_replace('/[^a-zA-Z0-9\-]/', ' ', $image['caption']['text']) : '',
					    'link'        => $image['link'],
					    'images'      => array(
						    'display'   => $image['images']['standard_resolution']['url'],
						    'thumbnail' => $image['images']['thumbnail']['url']
					    ),
				    );

				    if ( count($data_images) >= $count )
				    {
					    break;
				    }
			    }
		    }

		    if ( (($count - count($data_images)) > 0) && (count($data_images) % 12 == 0) && (count($data_images) > 0) && $method != 'username' )
		    {
			    $max_id = end( $data_images );
			    $max_id = $max_id['id'];

			    $next_images = $this->scrap_data( $username, $token, $method, ($count - 12), $max_id );

			    if ( !is_wp_error( $next_images ) )
			    {
				    $data_images = array_merge( $data_images, $next_images );
			    }
		    }

		    return $data_images;

	    }

	    return null;
    }

    function get_url( $username, $max_id )
    {
        $username = str_replace( '@', '', $username );

        if ( empty( $max_id ) )
        {
            return 'https://www.instagram.com/' . $username;
        } else {
            return 'https://www.instagram.com/' . $username . '?max_id=' . $max_id;
        }
    }

  	function images_only( $media_item ) {
  		if ( $media_item['type'] == 'image' )
  		return true;
  		return false;
  	}

 }

// register cairo_Socials_Widget
function register_cairo_instagram() {
   register_widget('widget_cairo_instagram');
}

add_action('widgets_init', 'register_cairo_instagram');
