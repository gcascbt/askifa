<?php

// ==========================================================================================
// Plugin Name: Cairo Addons & Shortcode
// Plugin URI: http://www.code-pages.com
// Description: A part of cairo theme
// Version: 2.1
// Author: Codepage Team
// Author URI: http://www.code-pages.com
// Text Domain: cairo
// ==========================================================================================

// Define Constants
defined('CP_ROOT') or define('CP_ROOT', plugin_dir_path( __FILE__ ));
defined('CP_URL') or define('CP_URL', plugin_dir_url( __FILE__ ));
define( 'CAIRO_THEME_NAME', esc_html_x( 'Cairo', 'Theme Name', 'cairo' ) );

//Shortcodes
if(!class_exists('codepages_shortcode')) {
  // Main plugin class //
  class codepages_shortcode {

    private $assets_css;
    private $assets_js;

   // Construct //
    public function __construct() {
      add_action('init', array($this,'cp_init'),50);
    }

   // Plugin activation //
    public static function activate() {
      flush_rewrite_rules();
    }

   // Plugin deactivation //
    public static function deactivate() {
      flush_rewrite_rules();
    }

   // Init //
    public function cp_init() {
      if (!defined('CAIRO_THEME_ACTIVATED') || CAIRO_THEME_ACTIVATED !== true) {
        add_action( 'admin_notices', array($this,'cp_activate_theme_notice') );
      } else {
        $this->assets_css = plugins_url('/composer/assets/css', __FILE__);
        add_action( 'admin_print_scripts-post.php',   array($this, 'cp_load_vc_scripts'), 99);
        add_action( 'admin_print_scripts-post-new.php', array($this, 'cp_load_vc_scripts'), 99);
        add_action('vc_load_default_params', array($this, 'cp_reload_vc_js'));

        if (class_exists('Vc_Manager')) {
          $this->cp_vc_load_shortcodes();
          $this->cp_init_vc();
          $this->cp_vc_integration();
        }
      }
    }

   // Print theme notice //
  function cp_activate_theme_notice() { ?>
    <div class="updated">
      <p><strong><?php _e('Please activate the Cairo theme to use Cairo Addons plugin.', 'cairo'); ?></strong></p>
      <?php
      $screen = get_current_screen();
      if ($screen -> base != 'themes'): ?>
        <p><a href="<?php echo esc_url(admin_url('themes.php')); ?>"><?php _e('Activate theme', 'cairo'); ?></a></p>
      <?php endif; ?>
    </div>
  <?php }

   // Init VC integration @global type $vc_manager //
    public function cp_init_vc() {
      global $vc_manager;
      $vc_manager->setIsAsTheme();
      $vc_manager->disableUpdater();
      $list = array( 'page', 'post');
      $vc_manager->setEditorDefaultPostTypes( $list );
      $vc_manager->setEditorPostTypes( $list ); //this is required after VC update (probably from vc 4.5 version)
      //$vc_manager->frontendEditor()->disableInline(); // enable/disable vc frontend editior
      $vc_manager->automapper()->setDisabled();
    }

   // Load shortcodes //
    public function cp_vc_load_shortcodes() {
      $shortcodes_path = plugin_dir_path( __FILE__ ) . 'shortcodes/';
      // VC shortcodes
      $dh = opendir( $shortcodes_path );
      while ( false !== ( $filename = readdir( $dh ) ) ) {
        if ( substr( $filename, 0, 1) != '_' && strrpos( $filename, '.' ) === false ) {
          include_once $shortcodes_path . $filename . '/' . $filename . '.php';
          include_once $shortcodes_path . $filename . '/' . $filename . '__params.php';
        }
      }

      // require_once(CP_ROOT. '/' . 'shortcodes/cp_featurd_slider.php');
      // require_once(CP_ROOT. '/' . 'shortcodes/cp_breaking_news.php');
      // require_once(CP_ROOT. '/' . 'shortcodes/cp_posts_grid.php');
      // require_once(CP_ROOT. '/' . 'shortcodes/cp_category_posts.php');
      // require_once(CP_ROOT. '/' . 'shortcodes/cp_video_posts.php');
      // require_once(CP_ROOT. '/' . 'shortcodes/cp_gallery_images.php');
      // require_once(CP_ROOT. '/' . 'shortcodes/cp_featured_boxes.php');
      // require_once(CP_ROOT. '/' . 'shortcodes/cp_diveder.php');
      // require_once(CP_ROOT. '/' . 'shortcodes/cp_title.php');
      // require_once(CP_ROOT. '/' . 'shortcodes/cp_instagram.php');
      // require_once(CP_ROOT. '/' . 'shortcodes/cp_subscribe_mailchimp.php');
      // require_once(CP_ROOT. '/' . 'shortcodes/cp_natifaction.php');
    }

   // Visual composer integration //
    public function cp_vc_integration() {
      require_once( CP_ROOT .'/' .'composer/vc_params.php' );
      // require_once( CP_ROOT .'/' .'composer/map.php' );
    }

   // Loand vc scripts //
    public function cp_load_vc_scripts() {
      wp_enqueue_style( 'rs-vc-custom', $this->assets_css. '/vc-style.css' );
    }

  } // end of class

  new codepages_shortcode;

  register_activation_hook( __FILE__, array( 'codepages_shortcode', 'activate' ) );
  register_deactivation_hook( __FILE__, array( 'codepages_shortcode', 'deactivate' ) );

} // end of class_exists //


// File integration //
require_once( CP_ROOT .'/' .'composer/social-share.php' );
require_once( CP_ROOT .'/' .'composer/widgets.php' );
require_once( CP_ROOT .'/' .'composer/user-profile.php' );
require_once( CP_ROOT .'/' .'demo-installer/init.php' );
