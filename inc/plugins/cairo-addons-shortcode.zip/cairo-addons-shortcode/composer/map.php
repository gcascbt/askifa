<?php

// ==========================================================================================
// Featurd Slider Style
// ==========================================================================================

if(function_exists('vc_map')){
	$posts_list = get_posts(array(
		'orderby' 	=> 'title',
		'order' 	=> 'ASC',
		'post_type' => 'post'
	));
	$posts_array = array();
	$posts_array[__("All Categories", 'cairo')] = "-";
	foreach($posts_list as $post) {
		$posts_array[$post->post_title . " (id:" . $post->ID . ")"] = $post->ID;
	}
	$post_categories = get_terms("category");
	$post_categories_array = array();
	$post_categories_array[__("All Categories", 'cairo')] = "-";
	foreach($post_categories as $post_category) {
		$post_categories_array[$post_category->name] =  $post_category->term_id;
	}

	//Image Creat Thump Parametre
	vc_add_shortcode_param( 'imagethup', 'my_param_settings_field' );
	function my_param_settings_field( $settings, $value ) {
	   return '<div class="my_param_block">'
		.'<input name="' . esc_attr( $settings['param_name'] ) . '" class="wpb_vc_param_value wpb-textinput ' .
		esc_attr( $settings['param_name'] ) . ' ' .
		esc_attr( $settings['type'] ) . '_field" type="hidden" value="' . esc_attr( $value ) . '" />
		<img src="'.esc_attr( $value ).'">'.
		'</div>'; // This is html markup that will be outputted in content elements edit form
	}








}


add_action('admin_init', 'vc_remove_elements');
function vc_remove_elements() {

	if (!class_exists('WPBakeryVisualComposerAbstract')) { // or using plugins path function
		return;
	}
	// Removing Default shortcodes
	vc_remove_element("vc_wp_search");
	vc_remove_element("vc_wp_recentcomments");
	vc_remove_element("vc_wp_calendar");
	vc_remove_element("vc_wp_pages");
	vc_remove_element("vc_wp_tagcloud");
	vc_remove_element("vc_wp_custommenu");
	vc_remove_element("vc_wp_text");
	vc_remove_element("vc_wp_posts");
	vc_remove_element("vc_wp_links");
	vc_remove_element("vc_wp_categories");
	vc_remove_element("vc_wp_archives");
	vc_remove_element("vc_wp_rss");
	vc_remove_element("vc_teaser_grid");
	vc_remove_element("vc_cta_button");
	vc_remove_element("vc_message");
	vc_remove_element("vc_progress_bar");
	vc_remove_element("vc_pie");
	vc_remove_element("vc_posts_slider");
	vc_remove_element("vc_posts_grid");
	vc_remove_element("vc_images_carousel");
	vc_remove_element("vc_carousel");
	vc_remove_element("vc_cta_button2");
	vc_remove_element("vc_separator");
	vc_remove_element("vc_custom_heading");

    //require_once get_template_directory() .'/inc/visualcomposer-extend.php';
}
